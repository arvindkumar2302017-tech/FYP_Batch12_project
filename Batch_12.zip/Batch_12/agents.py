"""
agents.py
=========
Reinforcement Learning Agents for Adaptive Sequential Learning Path Recommendation.

Implements:
1. ImprovedQLearningAgent: Tabular Q-learning with epsilon-greedy selection,
   epsilon decay (1.0 -> 0.05), learning rate decay, step-penalty reward shaping,
   repeated-action penalties, and model persistence.
2. SARSAgent: On-policy State-Action-Reward-State-Action control baseline.
3. RandomPolicyAgent: Uniform random exploration baseline.
"""

from abc import ABC, abstractmethod
from typing import Dict, Optional, Tuple, Any, List
import json
import os
import numpy as np

from environment import NUM_STATES, NUM_ACTIONS, STATE_NAMES, ACTION_NAMES


# ==============================================================================
# BASE REINFORCEMENT LEARNING AGENT
# ==============================================================================
class BaseRLAgent(ABC):
    """
    Abstract Base Class for Tabular Sequential Path Recommendation Agents.
    """

    def __init__(
        self,
        name: str,
        num_states: int = NUM_STATES,
        num_actions: int = NUM_ACTIONS,
        seed: Optional[int] = None,
    ):
        self.name = name
        self.num_states = num_states
        self.num_actions = num_actions
        self.rng = np.random.default_rng(seed)
        self.q_table = np.zeros((num_states, num_actions), dtype=np.float64)

    @abstractmethod
    def select_action(self, state: int, greedy: bool = False) -> int:
        """Select an action for the given state."""
        pass

    @abstractmethod
    def update(
        self,
        state: int,
        action: int,
        reward: float,
        next_state: int,
        terminated: bool,
        **kwargs,
    ) -> float:
        """Update Q-values and return TD error or absolute delta."""
        pass

    def get_q_table(self) -> np.ndarray:
        """Returns a copy of the current Q-table."""
        return self.q_table.copy()

    def get_policy(self) -> np.ndarray:
        """Returns greedy optimal action per state: pi*(s) = argmax_a Q(s, a)."""
        return np.argmax(self.q_table, axis=1)

    def save(self, filepath: str, extra_meta: Optional[Dict[str, Any]] = None) -> str:
        """
        Persists the agent's Q-table, hyperparameters, and metadata to JSON.
        """
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        payload = {
            "name": self.name,
            "num_states": self.num_states,
            "num_actions": self.num_actions,
            "q_table": self.q_table.tolist(),
            "policy": self.get_policy().tolist(),
            "state_names": STATE_NAMES,
            "action_names": ACTION_NAMES,
            "extra_meta": extra_meta or {},
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return filepath

    def load(self, filepath: str) -> None:
        """
        Loads the agent's Q-table and configuration from JSON.
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found: {filepath}")
        with open(filepath, "r", encoding="utf-8") as f:
            payload = json.load(f)
        self.name = payload.get("name", self.name)
        self.num_states = payload.get("num_states", self.num_states)
        self.num_actions = payload.get("num_actions", self.num_actions)
        self.q_table = np.array(payload["q_table"], dtype=np.float64)


# ==============================================================================
# IMPROVED Q-LEARNING AGENT
# ==============================================================================
class ImprovedQLearningAgent(BaseRLAgent):
    """
    Improved Q-Learning Algorithm for Adaptive Learning Path Recommendation.
    
    Key Innovations / Improvements:
    1. Epsilon-Greedy with documented exponential/linear decay from 1.0 down to 0.05.
    2. Learning-Rate Decay (Robbins-Monro condition): prevents oscillations as Q approaches convergence.
    3. Step-Penalty Reward Shaping: encourages shortest, most pedagogically efficient paths.
    4. Repeated-Action Penalties: discourages monotonous repetitive recommendations (combats learner fatigue).
    5. Configurable Discount Factor (gamma): defaults to 0.95.
    6. Full JSON model persistence with verifiable metadata.
    """

    def __init__(
        self,
        name: str = "Improved Q-Learning",
        num_states: int = NUM_STATES,
        num_actions: int = NUM_ACTIONS,
        gamma: float = 0.95,
        lr_init: float = 0.20,
        lr_min: float = 0.02,
        lr_decay: float = 0.005,
        epsilon_init: float = 1.0,
        epsilon_min: float = 0.05,
        epsilon_decay: float = 0.985,
        step_penalty: float = -1.0,
        repetition_penalty: float = -2.5,
        seed: Optional[int] = None,
    ):
        super().__init__(name=name, num_states=num_states, num_actions=num_actions, seed=seed)
        
        # Hyperparameters
        self.gamma = float(gamma)
        self.lr_init = float(lr_init)
        self.lr_min = float(lr_min)
        self.lr_decay = float(lr_decay)
        
        self.epsilon_init = float(epsilon_init)
        self.epsilon_min = float(epsilon_min)
        self.epsilon_decay = float(epsilon_decay)
        
        self.step_penalty = float(step_penalty)
        self.repetition_penalty = float(repetition_penalty)

        # Dynamic state
        self.current_epsilon = self.epsilon_init
        self.current_lr = self.lr_init
        self.episode_count = 0
        self.prev_action: Optional[int] = None

    def shape_reward(self, raw_reward: float, action: int, prev_action: Optional[int] = None) -> float:
        """
        Applies reward shaping:
        R_shaped = R_raw + step_penalty + (repetition_penalty if action == prev_action else 0.0)
        """
        shaped = raw_reward + self.step_penalty
        effective_prev = prev_action if prev_action is not None else self.prev_action
        if effective_prev is not None and action == effective_prev:
            shaped += self.repetition_penalty
        return shaped

    def select_action(self, state: int, greedy: bool = False) -> int:
        """
        Epsilon-greedy action selection with random tie-breaking.
        """
        if not greedy and self.rng.random() < self.current_epsilon:
            # Exploration
            return int(self.rng.integers(0, self.num_actions))

        # Exploitation: greedy with fair random tie-breaking
        q_values = self.q_table[state]
        max_q = np.max(q_values)
        best_actions = np.flatnonzero(q_values == max_q)
        if len(best_actions) == 1:
            return int(best_actions[0])
        return int(self.rng.choice(best_actions))

    def update(
        self,
        state: int,
        action: int,
        reward: float,
        next_state: int,
        terminated: bool,
        prev_action: Optional[int] = None,
        **kwargs,
    ) -> float:
        """
        Performs the off-policy Bellman Optimality Q-learning update:
        Q(s, a) <- Q(s, a) + alpha * [ R_shaped + gamma * max_a' Q(s', a') * (1 - term) - Q(s, a) ]
        
        Returns:
            float: Absolute change in Q-value |Delta Q(s, a)|.
        """
        shaped_reward = self.shape_reward(reward, action, prev_action)
        
        # Max future Q value for next state
        if terminated:
            target = shaped_reward
        else:
            best_next_q = np.max(self.q_table[next_state])
            target = shaped_reward + self.gamma * best_next_q

        current_q = self.q_table[state, action]
        td_error = target - current_q
        delta = self.current_lr * td_error
        
        self.q_table[state, action] = current_q + delta
        self.prev_action = action
        
        return float(abs(delta))

    def on_episode_end(self, episode_idx: int) -> None:
        """
        Decays exploration epsilon and learning rate after each episode.
        """
        self.episode_count = episode_idx + 1
        self.prev_action = None

        # Epsilon decay down to epsilon_min (0.05)
        self.current_epsilon = max(
            self.epsilon_min,
            self.current_epsilon * self.epsilon_decay,
        )

        # Learning rate decay down to lr_min
        # alpha(e) = alpha_0 / (1 + decay * e)
        self.current_lr = max(
            self.lr_min,
            self.lr_init / (1.0 + self.lr_decay * self.episode_count),
        )

    def reset_training_state(self, seed: Optional[int] = None) -> None:
        """Resets Q-table, learning rate, and epsilon for a clean training run."""
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.q_table = np.zeros((self.num_states, self.num_actions), dtype=np.float64)
        self.current_epsilon = self.epsilon_init
        self.current_lr = self.lr_init
        self.episode_count = 0
        self.prev_action = None


# ==============================================================================
# SARSA AGENT (ON-POLICY TD CONTROL BASELINE)
# ==============================================================================
class SARSAgent(BaseRLAgent):
    """
    SARSA (State-Action-Reward-State-Action) Agent.
    
    Standard on-policy Temporal Difference control baseline. Uses the exact same
    environment, reward structure, discount factor, and evaluation protocol as
    the Improved Q-learning agent to guarantee fair comparison.
    """

    def __init__(
        self,
        name: str = "SARSA",
        num_states: int = NUM_STATES,
        num_actions: int = NUM_ACTIONS,
        gamma: float = 0.95,
        lr_init: float = 0.20,
        lr_min: float = 0.02,
        lr_decay: float = 0.005,
        epsilon_init: float = 1.0,
        epsilon_min: float = 0.05,
        epsilon_decay: float = 0.985,
        step_penalty: float = -1.0,
        repetition_penalty: float = -2.5,
        seed: Optional[int] = None,
    ):
        super().__init__(name=name, num_states=num_states, num_actions=num_actions, seed=seed)
        
        self.gamma = float(gamma)
        self.lr_init = float(lr_init)
        self.lr_min = float(lr_min)
        self.lr_decay = float(lr_decay)
        
        self.epsilon_init = float(epsilon_init)
        self.epsilon_min = float(epsilon_min)
        self.epsilon_decay = float(epsilon_decay)
        
        self.step_penalty = float(step_penalty)
        self.repetition_penalty = float(repetition_penalty)

        self.current_epsilon = self.epsilon_init
        self.current_lr = self.lr_init
        self.episode_count = 0
        self.prev_action: Optional[int] = None

    def shape_reward(self, raw_reward: float, action: int, prev_action: Optional[int] = None) -> float:
        """Reward shaping identical to Improved Q-Learning."""
        shaped = raw_reward + self.step_penalty
        effective_prev = prev_action if prev_action is not None else self.prev_action
        if effective_prev is not None and action == effective_prev:
            shaped += self.repetition_penalty
        return shaped

    def select_action(self, state: int, greedy: bool = False) -> int:
        """Epsilon-greedy action selection."""
        if not greedy and self.rng.random() < self.current_epsilon:
            return int(self.rng.integers(0, self.num_actions))

        q_values = self.q_table[state]
        max_q = np.max(q_values)
        best_actions = np.flatnonzero(q_values == max_q)
        if len(best_actions) == 1:
            return int(best_actions[0])
        return int(self.rng.choice(best_actions))

    def update(
        self,
        state: int,
        action: int,
        reward: float,
        next_state: int,
        terminated: bool,
        next_action: Optional[int] = None,
        prev_action: Optional[int] = None,
        **kwargs,
    ) -> float:
        """
        On-policy SARSA update:
        Q(s, a) <- Q(s, a) + alpha * [ R_shaped + gamma * Q(s', a') * (1 - term) - Q(s, a) ]
        """
        shaped_reward = self.shape_reward(reward, action, prev_action)
        
        if terminated or next_action is None:
            target = shaped_reward
        else:
            target = shaped_reward + self.gamma * self.q_table[next_state, next_action]

        current_q = self.q_table[state, action]
        td_error = target - current_q
        delta = self.current_lr * td_error
        
        self.q_table[state, action] = current_q + delta
        self.prev_action = action
        
        return float(abs(delta))

    def on_episode_end(self, episode_idx: int) -> None:
        """Decay epsilon and learning rate after episode."""
        self.episode_count = episode_idx + 1
        self.prev_action = None

        self.current_epsilon = max(
            self.epsilon_min,
            self.current_epsilon * self.epsilon_decay,
        )
        self.current_lr = max(
            self.lr_min,
            self.lr_init / (1.0 + self.lr_decay * self.episode_count),
        )

    def reset_training_state(self, seed: Optional[int] = None) -> None:
        """Resets Q-table, learning rate, and epsilon for a clean training run."""
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.q_table = np.zeros((self.num_states, self.num_actions), dtype=np.float64)
        self.current_epsilon = self.epsilon_init
        self.current_lr = self.lr_init
        self.episode_count = 0
        self.prev_action = None


# ==============================================================================
# RANDOM POLICY AGENT (BASELINE)
# ==============================================================================
class RandomPolicyAgent(BaseRLAgent):
    """
    Stochastic Random Baseline Agent.
    
    Selects actions with uniform random probability across all 8 actions.
    Provides the empirical baseline for evaluating whether RL algorithms
    learn superior pedagogical paths.
    """

    def __init__(
        self,
        name: str = "Random Policy",
        num_states: int = NUM_STATES,
        num_actions: int = NUM_ACTIONS,
        seed: Optional[int] = None,
    ):
        super().__init__(name=name, num_states=num_states, num_actions=num_actions, seed=seed)

    def select_action(self, state: int, greedy: bool = False) -> int:
        """Always selects a uniform random action."""
        return int(self.rng.integers(0, self.num_actions))

    def update(
        self,
        state: int,
        action: int,
        reward: float,
        next_state: int,
        terminated: bool,
        **kwargs,
    ) -> float:
        """No-op for random baseline; returns 0.0 delta."""
        return 0.0

    def on_episode_end(self, episode_idx: int) -> None:
        """No-op for random baseline."""
        pass

    def reset_training_state(self, seed: Optional[int] = None) -> None:
        """Resets random generator."""
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.q_table = np.zeros((self.num_states, self.num_actions), dtype=np.float64)
