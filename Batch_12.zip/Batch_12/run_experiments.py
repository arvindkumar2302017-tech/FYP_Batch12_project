"""
run_experiments.py
==================
Batch execution script to train and evaluate all 3 algorithms
(Improved Q-Learning, SARSA, Random Baseline) across 100, 200, and 500 episode budgets.
Saves models to models/ and benchmark metrics to results/.
"""

import os
import json
import numpy as np
import pandas as pd

from environment import LearnerEnvironment
from agents import ImprovedQLearningAgent, SARSAgent, RandomPolicyAgent
from training import train_agent
from evaluation import evaluate_policy, run_benchmark_suite


def run_all(budgets=[100, 200, 500], base_seed=42, num_eval_episodes=100):
    print("=" * 70)
    print("STARTING EXPERIMENT BENCHMARK SUITE")
    print(f"Budgets: {budgets} | Base Seed: {base_seed} | Eval Episodes: {num_eval_episodes}")
    print("=" * 70)

    models_dir = "models"
    results_dir = "results"
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    env = LearnerEnvironment(seed=base_seed)
    trained_agents = {
        "Improved Q-Learning": {},
        "SARSA": {},
        "Random Policy": {},
    }
    training_histories = {}

    for budget in budgets:
        print(f"\n>>> Running Experiments for Episode Budget: {budget}")
        
        # 1. Improved Q-Learning
        print("  - Training Improved Q-Learning...")
        q_agent = ImprovedQLearningAgent(
            gamma=0.95,
            lr_init=0.20,
            lr_min=0.02,
            lr_decay=0.005,
            epsilon_init=1.0,
            epsilon_min=0.05,
            epsilon_decay=0.985,
            step_penalty=-1.0,
            repetition_penalty=-2.5,
            seed=base_seed + budget,
        )
        q_res = train_agent(
            env=env,
            agent=q_agent,
            num_episodes=budget,
            early_stopping=False,
            seed=base_seed + budget,
        )
        q_path = os.path.join(models_dir, f"q_learning_{budget}ep.json")
        q_agent.save(q_path, extra_meta={"budget": budget, "seed": base_seed})
        trained_agents["Improved Q-Learning"][budget] = q_agent
        training_histories[f"q_learning_{budget}"] = q_res

        # 2. SARSA
        print("  - Training SARSA...")
        s_agent = SARSAgent(
            gamma=0.95,
            lr_init=0.20,
            lr_min=0.02,
            lr_decay=0.005,
            epsilon_init=1.0,
            epsilon_min=0.05,
            epsilon_decay=0.985,
            step_penalty=-1.0,
            repetition_penalty=-2.5,
            seed=base_seed + budget,
        )
        s_res = train_agent(
            env=env,
            agent=s_agent,
            num_episodes=budget,
            early_stopping=False,
            seed=base_seed + budget,
        )
        s_path = os.path.join(models_dir, f"sarsa_{budget}ep.json")
        s_agent.save(s_path, extra_meta={"budget": budget, "seed": base_seed})
        trained_agents["SARSA"][budget] = s_agent
        training_histories[f"sarsa_{budget}"] = s_res

        # 3. Random Baseline
        print("  - Evaluating Random Policy...")
        r_agent = RandomPolicyAgent(seed=base_seed + budget)
        r_res = train_agent(
            env=env,
            agent=r_agent,
            num_episodes=budget,
            early_stopping=False,
            seed=base_seed + budget,
        )
        r_path = os.path.join(models_dir, f"random_{budget}ep.json")
        r_agent.save(r_path, extra_meta={"budget": budget, "seed": base_seed})
        trained_agents["Random Policy"][budget] = r_agent
        training_histories[f"random_{budget}"] = r_res

    # Save training histories
    with open(os.path.join(results_dir, "training_histories.json"), "w", encoding="utf-8") as f:
        # Convert histories to serializable dict
        serializable_hist = {}
        for k, v in training_histories.items():
            serializable_hist[k] = {
                "agent_name": v["agent_name"],
                "episodes_completed": v["episodes_completed"],
                "training_time_seconds": v["training_time_seconds"],
                "cumulative_rewards": v["cumulative_rewards"],
                "history": v["history"],
            }
        json.dump(serializable_hist, f, indent=2)

    # Run complete evaluation benchmark
    print("\n" + "=" * 70)
    print("RUNNING MULTI-SEED EVALUATION BENCHMARK (100 episodes per policy)...")
    print("=" * 70)
    df = run_benchmark_suite(
        agents_dict=trained_agents,
        num_eval_episodes=num_eval_episodes,
        base_seed=1000,
        results_dir=results_dir,
    )

    print("\nBENCHMARK RESULTS SUMMARY:")
    print(df.to_string(index=False))
    print("\nSaved artifacts to models/ and results/.")
    return df


if __name__ == "__main__":
    run_all()
