"""
training.py
===========
Training Loops, Convergence Diagnostics, and Multi-Budget Training Protocol.

Implements:
1. Flexible training loop with episode logging and optional early stopping.
2. Documented convergence criteria based on rolling maximum Q-table delta.
3. Multi-budget runner for 100, 200, and 500 episodes across Improved Q-Learning,
   SARSA, and Random Policy.
4. Model artifact saving into models/ directory.
"""

from typing import Dict, List, Optional, Tuple, Any, Callable
import time
import os
import numpy as np

from environment import (
    LearnerEnvironment,
    STATE_COMPLETED,
    STATE_DROPOUT,
    NUM_STATES,
    NUM_ACTIONS,
)
from agents import (
    BaseRLAgent,
    ImprovedQLearningAgent,
    SARSAgent,
    RandomPolicyAgent,
)


# ==============================================================================
# SINGLE AGENT TRAINING FUNCTION
# ==============================================================================
def train_agent(
    env: LearnerEnvironment,
    agent: BaseRLAgent,
    num_episodes: int,
    early_stopping: bool = False,
    convergence_tol: float = 1e-3,
    patience: int = 20,
    seed: Optional[int] = None,
    progress_callback: Optional[Callable[[int, int, Dict[str, Any]], None]] = None,
) -> Dict[str, Any]:
    """
    Trains an agent in the LearnerEnvironment.
    
    Convergence Criterion:
        Tracks the maximum absolute change across all Q-table cells per episode:
        Delta_Q_max(e) = max_{s, a} |Q_new(s, a) - Q_old(s, a)|.
        A sliding window of size `patience` computes the rolling average of Delta_Q_max.
        If early_stopping is True, and episode >= patience, and rolling_avg < convergence_tol,
        and agent exploration has matured (current_epsilon <= 0.15 if applicable),
        training halts early. Otherwise, the agent completes the full episode budget.
    """
    if seed is not None:
        agent.reset_training_state(seed=seed)
        env.reset(seed=seed)

    start_time = time.time()
    
    history: Dict[str, List[Any]] = {
        "episode_rewards": [],
        "shaped_rewards": [],
        "episode_lengths": [],
        "episode_outcomes": [],
        "epsilon_history": [],
        "lr_history": [],
        "delta_q_history": [],
    }

    converged = False
    converged_episode: Optional[int] = None
    delta_window: List[float] = []

    for ep in range(num_episodes):
        state, _ = env.reset()
        ep_reward = 0.0
        ep_shaped_reward = 0.0
        ep_delta_q = 0.0
        prev_action = None

        # Determine agent type logic
        is_sarsa = isinstance(agent, SARSAgent)
        is_improved_q = isinstance(agent, ImprovedQLearningAgent)
        
        # Initial action for SARSA
        current_action = agent.select_action(state, greedy=False) if is_sarsa else None

        terminated = False
        truncated = False

        while not (terminated or truncated):
            if is_sarsa:
                action = current_action
            else:
                action = agent.select_action(state, greedy=False)

            next_state, base_reward, terminated, truncated, info = env.step(action)
            ep_reward += base_reward

            # Update Q-values
            if is_sarsa:
                if terminated:
                    next_action = None
                else:
                    next_action = agent.select_action(next_state, greedy=False)
                
                delta = agent.update(
                    state=state,
                    action=action,
                    reward=base_reward,
                    next_state=next_state,
                    terminated=terminated,
                    next_action=next_action,
                    prev_action=prev_action,
                )
                if hasattr(agent, "shape_reward"):
                    ep_shaped_reward += agent.shape_reward(base_reward, action, prev_action)
                current_action = next_action
            else:
                delta = agent.update(
                    state=state,
                    action=action,
                    reward=base_reward,
                    next_state=next_state,
                    terminated=terminated,
                    prev_action=prev_action,
                )
                if hasattr(agent, "shape_reward"):
                    ep_shaped_reward += agent.shape_reward(base_reward, action, prev_action)
                else:
                    ep_shaped_reward += base_reward

            ep_delta_q = max(ep_delta_q, delta)
            prev_action = action
            state = next_state

        # Determine episode terminal outcome
        if env.state == STATE_COMPLETED:
            outcome = "completed"
        elif env.state == STATE_DROPOUT:
            outcome = "dropout"
        else:
            outcome = "truncated"

        # End of episode hook for agent (e.g. epsilon/lr decay)
        if hasattr(agent, "on_episode_end"):
            agent.on_episode_end(ep)

        # Logging metrics
        history["episode_rewards"].append(ep_reward)
        history["shaped_rewards"].append(ep_shaped_reward)
        history["episode_lengths"].append(env.step_count)
        history["episode_outcomes"].append(outcome)
        history["delta_q_history"].append(ep_delta_q)
        
        curr_eps = getattr(agent, "current_epsilon", 0.0)
        curr_lr = getattr(agent, "current_lr", 0.0)
        history["epsilon_history"].append(curr_eps)
        history["lr_history"].append(curr_lr)

        # Convergence test
        delta_window.append(ep_delta_q)
        if len(delta_window) > patience:
            delta_window.pop(0)

        if (
            early_stopping
            and len(delta_window) == patience
            and np.mean(delta_window) < convergence_tol
            and (curr_eps <= 0.15 or not hasattr(agent, "current_epsilon"))
        ):
            converged = True
            converged_episode = ep + 1
            if progress_callback:
                progress_callback(ep + 1, num_episodes, {
                    "reward": ep_reward,
                    "length": env.step_count,
                    "outcome": outcome,
                    "converged": True,
                })
            break

        if progress_callback and (ep % 10 == 0 or ep == num_episodes - 1):
            progress_callback(ep + 1, num_episodes, {
                "reward": ep_reward,
                "length": env.step_count,
                "outcome": outcome,
                "converged": False,
            })

    elapsed_time = time.time() - start_time
    cumulative_rewards = np.cumsum(history["episode_rewards"]).tolist()

    return {
        "agent_name": agent.name,
        "episodes_requested": num_episodes,
        "episodes_completed": len(history["episode_rewards"]),
        "converged": converged,
        "converged_episode": converged_episode,
        "training_time_seconds": round(elapsed_time, 4),
        "history": history,
        "cumulative_rewards": cumulative_rewards,
        "final_q_table": agent.get_q_table().tolist(),
        "final_policy": agent.get_policy().tolist(),
    }


# ==============================================================================
# MULTI-BUDGET TRAINING PROTOCOL (100, 200, 500 EPISODES)
# ==============================================================================
def train_multi_budget_experiment(
    budgets: List[int] = [100, 200, 500],
    seed: int = 42,
    models_dir: str = "models",
    early_stopping: bool = False,
) -> Dict[str, Dict[int, Dict[str, Any]]]:
    """
    Executes training for all three policies (Improved Q-Learning, SARSA, Random)
    at the specified episode budgets (100, 200, 500).
    
    Saves trained Q-tables and training metadata into `models_dir`.
    """
    os.makedirs(models_dir, exist_ok=True)
    all_results: Dict[str, Dict[int, Dict[str, Any]]] = {
        "Improved Q-Learning": {},
        "SARSA": {},
        "Random Policy": {},
    }

    env = LearnerEnvironment(seed=seed)

    for budget in budgets:
        # 1. Improved Q-Learning
        q_agent = ImprovedQLearningAgent(
            gamma=0.95,
            lr_init=0.20,
            lr_min=0.02,
            lr_decay=0.005,
            epsilon_init=1.0,
            epsilon_min=0.05,
            epsilon_decay=0.985,
            step_penalty=-1.0,
            repetition_penalty=-2.5,
            seed=seed + budget,
        )
        q_res = train_agent(
            env=env,
            agent=q_agent,
            num_episodes=budget,
            early_stopping=early_stopping,
            seed=seed + budget,
        )
        all_results["Improved Q-Learning"][budget] = q_res
        q_agent.save(
            os.path.join(models_dir, f"q_learning_{budget}ep.json"),
            extra_meta={"budget": budget, "seed": seed, "converged": q_res["converged"]},
        )

        # 2. SARSA
        sarsa_agent = SARSAgent(
            gamma=0.95,
            lr_init=0.20,
            lr_min=0.02,
            lr_decay=0.005,
            epsilon_init=1.0,
            epsilon_min=0.05,
            epsilon_decay=0.985,
            step_penalty=-1.0,
            repetition_penalty=-2.5,
            seed=seed + budget,
        )
        sarsa_res = train_agent(
            env=env,
            agent=sarsa_agent,
            num_episodes=budget,
            early_stopping=early_stopping,
            seed=seed + budget,
        )
        all_results["SARSA"][budget] = sarsa_res
        sarsa_agent.save(
            os.path.join(models_dir, f"sarsa_{budget}ep.json"),
            extra_meta={"budget": budget, "seed": seed, "converged": sarsa_res["converged"]},
        )

        # 3. Random Baseline
        rand_agent = RandomPolicyAgent(seed=seed + budget)
        rand_res = train_agent(
            env=env,
            agent=rand_agent,
            num_episodes=budget,
            early_stopping=False,
            seed=seed + budget,
        )
        all_results["Random Policy"][budget] = rand_res
        rand_agent.save(
            os.path.join(models_dir, f"random_{budget}ep.json"),
            extra_meta={"budget": budget, "seed": seed},
        )

    return all_results
