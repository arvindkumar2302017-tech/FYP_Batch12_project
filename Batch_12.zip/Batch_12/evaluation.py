"""
evaluation.py
=============
Evaluation Protocol, Empirical Metrics Computation, and Benchmark Runner.

Strictly follows empirical measurement standards:
- Runs multiple seeded evaluation episodes (default 50 or 100) using greedy policies.
- Computes actual measured results for:
    * Success Rate (%)
    * Mean Episode Reward (+/- Std)
    * Average Path Length (+/- Std)
    * Dropout Rate (%) and Truncation Rate (%)
- Never hardcodes expected results or assumes guaranteed superiority.
- Saves benchmark tables to CSV and JSON formats in results/ directory.
"""

from typing import Dict, List, Optional, Tuple, Any
import os
import json
import numpy as np
import pandas as pd

from environment import (
    LearnerEnvironment,
    STATE_START,
    STATE_COMPLETED,
    STATE_DROPOUT,
    STATE_NAMES,
    ACTION_NAMES,
    STATE_DESCRIPTIONS,
    ACTION_DESCRIPTIONS,
)
from agents import BaseRLAgent


# ==============================================================================
# SINGLE POLICY EVALUATOR
# ==============================================================================
def evaluate_policy(
    env: LearnerEnvironment,
    agent: BaseRLAgent,
    num_eval_episodes: int = 50,
    base_seed: int = 1000,
) -> Dict[str, Any]:
    """
    Evaluates an agent over multiple seeded episodes using pure greedy exploitation.
    
    Args:
        env (LearnerEnvironment): The environment instance.
        agent (BaseRLAgent): Trained agent to evaluate.
        num_eval_episodes (int): Number of independent evaluation rollouts.
        base_seed (int): Base random seed for reproducible evaluation.
        
    Returns:
        Dict[str, Any]: Comprehensive measured metrics dictionary.
    """
    total_rewards: List[float] = []
    path_lengths: List[int] = []
    outcomes: List[str] = []
    sample_trajectories: List[List[Dict[str, Any]]] = []

    for i in range(num_eval_episodes):
        ep_seed = base_seed + i
        state, _ = env.reset(seed=ep_seed)
        ep_reward = 0.0
        trajectory: List[Dict[str, Any]] = []

        terminated = False
        truncated = False

        while not (terminated or truncated):
            # Greedy action selection during evaluation
            action = agent.select_action(state, greedy=True)
            next_state, reward, terminated, truncated, info = env.step(action)
            ep_reward += reward

            trajectory.append({
                "step": env.step_count,
                "state_id": state,
                "state_name": STATE_NAMES[state],
                "action_id": action,
                "action_name": ACTION_NAMES[action],
                "reward": reward,
                "next_state_id": next_state,
                "next_state_name": STATE_NAMES[next_state],
                "terminated": terminated,
            })
            state = next_state

        if env.state == STATE_COMPLETED:
            outcome = "completed"
        elif env.state == STATE_DROPOUT:
            outcome = "dropout"
        else:
            outcome = "truncated"

        total_rewards.append(ep_reward)
        path_lengths.append(env.step_count)
        outcomes.append(outcome)
        
        # Save first 3 trajectories for qualitative inspection
        if i < 3:
            sample_trajectories.append(trajectory)

    # Compute actual empirical metrics
    completed_count = sum(1 for o in outcomes if o == "completed")
    dropout_count = sum(1 for o in outcomes if o == "dropout")
    truncated_count = sum(1 for o in outcomes if o == "truncated")

    success_rate = (completed_count / num_eval_episodes) * 100.0
    dropout_rate = (dropout_count / num_eval_episodes) * 100.0
    truncation_rate = (truncated_count / num_eval_episodes) * 100.0

    mean_reward = float(np.mean(total_rewards))
    std_reward = float(np.std(total_rewards))
    min_reward = float(np.min(total_rewards))
    max_reward = float(np.max(total_rewards))

    mean_path_len = float(np.mean(path_lengths))
    std_path_len = float(np.std(path_lengths))
    min_path_len = int(np.min(path_lengths))
    max_path_len = int(np.max(path_lengths))

    return {
        "agent_name": agent.name,
        "num_eval_episodes": num_eval_episodes,
        "success_rate_pct": round(success_rate, 2),
        "dropout_rate_pct": round(dropout_rate, 2),
        "truncation_rate_pct": round(truncation_rate, 2),
        "mean_reward": round(mean_reward, 2),
        "std_reward": round(std_reward, 2),
        "min_reward": round(min_reward, 2),
        "max_reward": round(max_reward, 2),
        "mean_path_length": round(mean_path_len, 2),
        "std_path_length": round(std_path_len, 2),
        "min_path_length": min_path_len,
        "max_path_length": max_path_len,
        "raw_rewards": total_rewards,
        "raw_lengths": path_lengths,
        "raw_outcomes": outcomes,
        "sample_trajectories": sample_trajectories,
    }


# ==============================================================================
# BENCHMARK RUNNER ACROSS ALGORITHMS AND BUDGETS (100, 200, 500)
# ==============================================================================
def run_benchmark_suite(
    agents_dict: Dict[str, Dict[int, BaseRLAgent]],
    num_eval_episodes: int = 50,
    base_seed: int = 1000,
    results_dir: str = "results",
) -> pd.DataFrame:
    """
    Evaluates trained agents across budgets (100, 200, 500) and compiles
    a clean benchmark DataFrame.
    """
    os.makedirs(results_dir, exist_ok=True)
    env = LearnerEnvironment()
    records = []
    full_eval_data: Dict[str, Any] = {}

    for algo_name, budget_dict in agents_dict.items():
        full_eval_data[algo_name] = {}
        for budget, agent in budget_dict.items():
            eval_metrics = evaluate_policy(
                env=env,
                agent=agent,
                num_eval_episodes=num_eval_episodes,
                base_seed=base_seed,
            )
            full_eval_data[algo_name][str(budget)] = eval_metrics

            records.append({
                "Algorithm": algo_name,
                "Budget": budget,
                "Success Rate (%)": eval_metrics["success_rate_pct"],
                "Mean Reward": eval_metrics["mean_reward"],
                "Std Reward": eval_metrics["std_reward"],
                "Avg Path Length": eval_metrics["mean_path_length"],
                "Dropout Rate (%)": eval_metrics["dropout_rate_pct"],
                "Truncation Rate (%)": eval_metrics["truncation_rate_pct"],
            })

    df = pd.DataFrame(records)
    
    # Export CSV and JSON
    csv_path = os.path.join(results_dir, "benchmark_summary.csv")
    json_path = os.path.join(results_dir, "benchmark_summary.json")
    df.to_csv(csv_path, index=False)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(full_eval_data, f, indent=2)

    return df


# ==============================================================================
# STEP-BY-STEP SIMULATOR HELPER FOR DASHBOARD
# ==============================================================================
def simulate_single_path(
    env: LearnerEnvironment,
    agent: BaseRLAgent,
    initial_state: int = STATE_START,
    max_steps: int = 25,
    seed: Optional[int] = None,
) -> pd.DataFrame:
    """
    Simulates a single pedagogical trajectory starting from `initial_state`
    using the agent's greedy policy. Returns a readable pandas DataFrame.
    """
    if seed is not None:
        env.reset(seed=seed)
    else:
        env.reset()

    env.state = initial_state
    rows = []
    step_num = 0

    while env.state not in [STATE_COMPLETED, STATE_DROPOUT] and step_num < max_steps:
        curr_state = env.state
        action = agent.select_action(curr_state, greedy=True)
        next_state, reward, terminated, truncated, info = env.step(action)
        step_num += 1

        rows.append({
            "Step": step_num,
            "Current State": STATE_NAMES[curr_state],
            "Recommended Action": ACTION_NAMES[action],
            "Next State": STATE_NAMES[next_state],
            "Step Reward": reward,
            "Terminal": "Yes (Success)" if next_state == STATE_COMPLETED else (
                "Yes (Dropout)" if next_state == STATE_DROPOUT else "No"
            ),
        })
        if terminated:
            break

    return pd.DataFrame(rows)
