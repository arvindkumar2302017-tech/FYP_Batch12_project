"""
tests/test_agents.py
====================
Unit tests for Reinforcement Learning Agents.

Verifies:
1. Q-table shape (11, 8) and zero initialization.
2. Epsilon decay strictly bounds between [0.05, 1.0].
3. Learning-rate decay respects Robbins-Monro lower bound lr_min.
4. Reward shaping applies step-penalty and repeated-action penalties correctly.
5. Hand-calculated Bellman Optimality Q-update matches implementation.
6. Hand-calculated on-policy SARSA Q-update matches implementation.
7. Model persistence: save and load preserves Q-table and metadata bit-for-bit.
"""

import os
import pytest
import numpy as np

from environment import NUM_STATES, NUM_ACTIONS
from agents import (
    ImprovedQLearningAgent,
    SARSAgent,
    RandomPolicyAgent,
)


def test_q_table_dimensions():
    """Verify Q-tables are initialized with correct dimensions (11, 8) of zeros."""
    q_agent = ImprovedQLearningAgent()
    s_agent = SARSAgent()
    r_agent = RandomPolicyAgent()

    assert q_agent.q_table.shape == (NUM_STATES, NUM_ACTIONS)
    assert s_agent.q_table.shape == (NUM_STATES, NUM_ACTIONS)
    assert r_agent.q_table.shape == (NUM_STATES, NUM_ACTIONS)
    assert np.all(q_agent.q_table == 0.0)


def test_epsilon_decay_bounds():
    """Verify epsilon decays smoothly from 1.0 to exactly 0.05 without undershooting."""
    agent = ImprovedQLearningAgent(
        epsilon_init=1.0,
        epsilon_min=0.05,
        epsilon_decay=0.9,
    )
    assert agent.current_epsilon == 1.0

    # Simulate 50 episodes
    epsilons = []
    for ep in range(50):
        agent.on_episode_end(ep)
        epsilons.append(agent.current_epsilon)
        assert 0.05 <= agent.current_epsilon <= 1.0

    # Verify monotonic decay
    assert all(x >= y for x, y in zip(epsilons, epsilons[1:]))
    # After 50 episodes with decay 0.9, should reach minimum 0.05
    assert agent.current_epsilon == pytest.approx(0.05, rel=1e-5)


def test_learning_rate_decay_bounds():
    """Verify learning rate decays monotonically from lr_init down to lr_min."""
    agent = ImprovedQLearningAgent(
        lr_init=0.20,
        lr_min=0.02,
        lr_decay=0.05,
    )
    assert agent.current_lr == 0.20

    lrs = []
    for ep in range(100):
        agent.on_episode_end(ep)
        lrs.append(agent.current_lr)
        assert 0.02 <= agent.current_lr <= 0.20

    assert all(x >= y for x, y in zip(lrs, lrs[1:]))
    assert agent.current_lr >= 0.02


def test_reward_shaping():
    """Verify step penalty and repeated-action penalties are correctly shaped."""
    agent = ImprovedQLearningAgent(
        step_penalty=-1.0,
        repetition_penalty=-2.5,
    )

    raw_reward = 10.0
    # First action (no repetition)
    r1 = agent.shape_reward(raw_reward, action=2, prev_action=None)
    assert r1 == 10.0 + (-1.0)  # 9.0

    # Different consecutive action (no repetition)
    r2 = agent.shape_reward(raw_reward, action=3, prev_action=2)
    assert r2 == 10.0 + (-1.0)  # 9.0

    # Identical consecutive action (repetition penalty applies)
    r3 = agent.shape_reward(raw_reward, action=2, prev_action=2)
    assert r3 == 10.0 + (-1.0) + (-2.5)  # 6.5


def test_improved_q_learning_update_mathematics():
    """
    Verify exact mathematical correctness of Improved Q-Learning Bellman update:
    Q(s, a) <- Q(s, a) + alpha * [ R_shaped + gamma * max_a' Q(s', a') - Q(s, a) ]
    """
    agent = ImprovedQLearningAgent(
        gamma=0.90,
        lr_init=0.10,
        step_penalty=-1.0,
        repetition_penalty=-2.0,
    )
    agent.current_lr = 0.10

    # Initialize custom Q-values for test
    s, a = 1, 2
    next_s = 3
    agent.q_table[s, a] = 5.0
    agent.q_table[next_s] = np.array([1.0, 2.0, 8.0, 4.0, 0.0, 0.0, 0.0, 0.0])
    # max_a' Q(next_s, a') = 8.0

    raw_reward = 15.0
    prev_action = 1  # different action, no repeat penalty

    # Analytical calculation:
    # shaped_reward = 15.0 + (-1.0) = 14.0
    # target = 14.0 + 0.90 * 8.0 = 14.0 + 7.2 = 21.2
    # td_error = 21.2 - 5.0 = 16.2
    # delta = 0.10 * 16.2 = 1.62
    # new_q = 5.0 + 1.62 = 6.62

    delta = agent.update(
        state=s,
        action=a,
        reward=raw_reward,
        next_state=next_s,
        terminated=False,
        prev_action=prev_action,
    )

    assert pytest.approx(delta, rel=1e-5) == 1.62
    assert pytest.approx(agent.q_table[s, a], rel=1e-5) == 6.62


def test_sarsa_update_mathematics():
    """
    Verify exact mathematical correctness of on-policy SARSA update:
    Q(s, a) <- Q(s, a) + alpha * [ R_shaped + gamma * Q(s', a') - Q(s, a) ]
    """
    agent = SARSAgent(
        gamma=0.90,
        lr_init=0.10,
        step_penalty=-1.0,
        repetition_penalty=-2.0,
    )
    agent.current_lr = 0.10

    s, a = 2, 1
    next_s, next_a = 4, 3
    agent.q_table[s, a] = 4.0
    agent.q_table[next_s, next_a] = 10.0

    raw_reward = 8.0
    # prev_action = 1 (repetition penalty applies because a == prev_action)
    # shaped_reward = 8.0 + (-1.0) + (-2.0) = 5.0
    # target = 5.0 + 0.90 * 10.0 = 14.0
    # td_error = 14.0 - 4.0 = 10.0
    # delta = 0.10 * 10.0 = 1.0
    # new_q = 4.0 + 1.0 = 5.0

    delta = agent.update(
        state=s,
        action=a,
        reward=raw_reward,
        next_state=next_s,
        terminated=False,
        next_action=next_a,
        prev_action=1,
    )

    assert pytest.approx(delta, rel=1e-5) == 1.0
    assert pytest.approx(agent.q_table[s, a], rel=1e-5) == 5.0


def test_random_agent_action_bounds():
    """Verify random policy agent produces integer actions strictly in [0, 7]."""
    agent = RandomPolicyAgent(seed=42)
    actions = [agent.select_action(0) for _ in range(100)]
    assert all(0 <= a < NUM_ACTIONS for a in actions)
    assert len(set(actions)) > 1  # Should explore multiple actions


def test_model_persistence_roundtrip(tmp_path):
    """Verify agent Q-table and metadata save and load with perfect fidelity."""
    filepath = str(tmp_path / "test_model.json")
    agent = ImprovedQLearningAgent(seed=42)
    # Fill with distinctive pseudo-random Q-values
    agent.q_table = np.arange(NUM_STATES * NUM_ACTIONS, dtype=np.float64).reshape((NUM_STATES, NUM_ACTIONS)) * 1.5

    agent.save(filepath, extra_meta={"test_flag": True})
    assert os.path.exists(filepath)

    new_agent = ImprovedQLearningAgent()
    new_agent.load(filepath)

    assert np.allclose(agent.q_table, new_agent.q_table)
    assert np.array_equal(agent.get_policy(), new_agent.get_policy())
