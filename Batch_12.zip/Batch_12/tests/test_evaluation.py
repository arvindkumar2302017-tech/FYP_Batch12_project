"""
tests/test_evaluation.py
========================
Unit tests for the Evaluation Protocol and Benchmark Suite.

Verifies:
1. Multi-seed policy evaluation returns mathematically consistent rates (sum to 100%).
2. Success rate, mean reward, and path length computation.
3. Path lengths are strictly between 1 and max_steps.
4. Trajectory simulation produces complete valid DataFrames.
5. Benchmark runner exports valid summaries to results/ directory.
"""

import os
import pytest
import numpy as np
import pandas as pd

from environment import LearnerEnvironment
from agents import ImprovedQLearningAgent, RandomPolicyAgent
from evaluation import (
    evaluate_policy,
    simulate_single_path,
    run_benchmark_suite,
)


def test_evaluate_policy_metric_consistency():
    """Verify evaluation percentages sum to 100% and rewards are calculated."""
    env = LearnerEnvironment()
    agent = RandomPolicyAgent(seed=42)

    metrics = evaluate_policy(
        env=env,
        agent=agent,
        num_eval_episodes=40,
        base_seed=5000,
    )

    assert "success_rate_pct" in metrics
    assert "dropout_rate_pct" in metrics
    assert "truncation_rate_pct" in metrics
    assert "mean_reward" in metrics
    assert "mean_path_length" in metrics

    total_pct = (
        metrics["success_rate_pct"]
        + metrics["dropout_rate_pct"]
        + metrics["truncation_rate_pct"]
    )
    assert pytest.approx(total_pct, rel=1e-3) == 100.0

    assert 0.0 <= metrics["success_rate_pct"] <= 100.0
    assert 0.0 <= metrics["dropout_rate_pct"] <= 100.0
    assert 1 <= metrics["mean_path_length"] <= env.max_steps


def test_simulate_single_path():
    """Verify trajectory simulation DataFrame format and non-empty steps."""
    env = LearnerEnvironment()
    agent = ImprovedQLearningAgent(seed=42)

    df = simulate_single_path(
        env=env,
        agent=agent,
        initial_state=0,
        max_steps=15,
        seed=100,
    )

    assert isinstance(df, pd.DataFrame)
    assert not df.empty
    expected_cols = [
        "Step",
        "Current State",
        "Recommended Action",
        "Next State",
        "Step Reward",
        "Terminal",
    ]
    for col in expected_cols:
        assert col in df.columns


def test_benchmark_suite_execution(tmp_path):
    """Verify run_benchmark_suite builds and saves benchmark DataFrame."""
    results_dir = str(tmp_path / "test_results")
    
    agent_q = ImprovedQLearningAgent(seed=1)
    agent_r = RandomPolicyAgent(seed=2)

    agents_dict = {
        "Improved Q-Learning": {10: agent_q},
        "Random Policy": {10: agent_r},
    }

    df = run_benchmark_suite(
        agents_dict=agents_dict,
        num_eval_episodes=10,
        base_seed=123,
        results_dir=results_dir,
    )

    assert isinstance(df, pd.DataFrame)
    assert len(df) == 2
    assert os.path.exists(os.path.join(results_dir, "benchmark_summary.csv"))
    assert os.path.exists(os.path.join(results_dir, "benchmark_summary.json"))
