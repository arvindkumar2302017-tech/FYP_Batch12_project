"""
tests/test_training.py
======================
Unit tests for the Training Loop and Multi-Budget Experiment Runner.

Verifies:
1. Training loop completes requested episode budget without early stopping.
2. Documented early stopping triggers when convergence criterion is met.
3. Deterministic training reproducibility using fixed random seeds.
4. Correct structure of history dict and cumulative rewards.
"""

import pytest
import numpy as np

from environment import LearnerEnvironment
from agents import ImprovedQLearningAgent, SARSAgent, RandomPolicyAgent
from training import train_agent, train_multi_budget_experiment


def test_train_agent_completes_budget():
    """Verify training runs through exactly requested episodes when early stopping is False."""
    env = LearnerEnvironment(seed=42)
    agent = ImprovedQLearningAgent(seed=42)
    budget = 50

    res = train_agent(
        env=env,
        agent=agent,
        num_episodes=budget,
        early_stopping=False,
        seed=42,
    )

    assert res["episodes_completed"] == budget
    assert len(res["history"]["episode_rewards"]) == budget
    assert len(res["history"]["episode_lengths"]) == budget
    assert len(res["history"]["episode_outcomes"]) == budget
    assert len(res["cumulative_rewards"]) == budget
    assert res["converged"] is False


def test_early_stopping_convergence():
    """
    Verify early stopping terminates when Q delta is below tolerance
    and exploration has matured.
    """
    env = LearnerEnvironment(seed=42)
    # Set high decay and loose tolerance to easily trigger early stopping in small episodes
    agent = ImprovedQLearningAgent(
        epsilon_init=0.10,
        epsilon_decay=0.5,
        lr_init=0.01,
        lr_decay=0.1,
        seed=42,
    )

    res = train_agent(
        env=env,
        agent=agent,
        num_episodes=300,
        early_stopping=True,
        convergence_tol=10.0,  # Generous tolerance to verify early exit mechanism
        patience=10,
        seed=42,
    )

    assert res["converged"] is True
    assert res["converged_episode"] is not None
    assert res["episodes_completed"] < 300


def test_deterministic_training_reproducibility():
    """Verify two training runs with identical seed yield exact identical Q-tables."""
    env1 = LearnerEnvironment(seed=777)
    agent1 = ImprovedQLearningAgent(seed=777)
    res1 = train_agent(env=env1, agent=agent1, num_episodes=40, seed=777)

    env2 = LearnerEnvironment(seed=777)
    agent2 = ImprovedQLearningAgent(seed=777)
    res2 = train_agent(env=env2, agent=agent2, num_episodes=40, seed=777)

    assert res1["history"]["episode_rewards"] == res2["history"]["episode_rewards"]
    assert np.allclose(agent1.get_q_table(), agent2.get_q_table())
