"""
tests/test_environment.py
==========================
Unit tests for the LearnerEnvironment.

Verifies:
1. State/action validity: exactly 11 states and 8 actions.
2. Transition probability distributions sum to 1.0 for all (s, a) pairs.
3. Terminal states (S9_COMPLETED and S10_DROPOUT) terminate episodes.
4. Truncation flags when max_steps is exceeded.
5. Deterministic reproducibility with random seeds.
6. Environment reset logic.
"""

import pytest
import numpy as np

from environment import (
    LearnerEnvironment,
    NUM_STATES,
    NUM_ACTIONS,
    STATE_START,
    STATE_READING,
    STATE_VIDEO,
    STATE_WRITING,
    STATE_QUIZ,
    STATE_ADVANCED,
    STATE_REVISION,
    STATE_BORED,
    STATE_FRUSTRATED,
    STATE_COMPLETED,
    STATE_DROPOUT,
    TERMINAL_STATES,
    TRANSITION_PROBABILITIES,
    BASE_REWARD_TABLE,
    STATE_NAMES,
    ACTION_NAMES,
)


def test_state_and_action_cardinalities():
    """Verify exactly 11 states and 8 actions exist and are registered."""
    assert NUM_STATES == 11
    assert NUM_ACTIONS == 8
    assert len(STATE_NAMES) == 11
    assert len(ACTION_NAMES) == 8


def test_required_state_presence():
    """Verify presence of reading, video, writing, bored, frustrated, completed, dropout."""
    required_states = [
        STATE_READING,
        STATE_VIDEO,
        STATE_WRITING,
        STATE_BORED,
        STATE_FRUSTRATED,
        STATE_COMPLETED,
        STATE_DROPOUT,
    ]
    for st in required_states:
        assert 0 <= st < NUM_STATES
        assert st in STATE_NAMES


def test_transition_probability_conservation():
    """Verify sum of transition probabilities is exactly 1.0 for all states and actions."""
    for s in range(NUM_STATES):
        assert s in TRANSITION_PROBABILITIES
        for a in range(NUM_ACTIONS):
            assert a in TRANSITION_PROBABILITIES[s]
            probs = TRANSITION_PROBABILITIES[s][a]
            assert len(probs) > 0
            prob_sum = sum(probs.values())
            assert pytest.approx(prob_sum, rel=1e-5) == 1.0
            for next_s, p in probs.items():
                assert 0.0 <= p <= 1.0
                assert 0 <= next_s < NUM_STATES


def test_terminal_absorbing_nature():
    """Verify terminal states (S9, S10) loop to themselves with zero reward."""
    for term_s in TERMINAL_STATES:
        for a in range(NUM_ACTIONS):
            assert TRANSITION_PROBABILITIES[term_s][a] == {term_s: 1.0}

    env = LearnerEnvironment()
    env.state = STATE_COMPLETED
    next_s, r, terminated, truncated, info = env.step(0)
    assert next_s == STATE_COMPLETED
    assert r == 0.0
    assert terminated is True

    env.state = STATE_DROPOUT
    next_s, r, terminated, truncated, info = env.step(1)
    assert next_s == STATE_DROPOUT
    assert r == 0.0
    assert terminated is True


def test_reset_behavior():
    """Verify reset always returns state 0 with correct info."""
    env = LearnerEnvironment()
    env.state = STATE_WRITING
    env.step_count = 15

    state, info = env.reset(seed=123)
    assert state == STATE_START
    assert env.step_count == 0
    assert env.prev_action is None
    assert info["is_terminal"] is False


def test_step_invalid_action():
    """Verify invalid action raises ValueError."""
    env = LearnerEnvironment()
    env.reset()
    with pytest.raises(ValueError):
        env.step(-1)
    with pytest.raises(ValueError):
        env.step(8)


def test_max_steps_truncation():
    """Verify truncation triggers when step_count reaches max_steps without terminating."""
    max_steps = 5
    env = LearnerEnvironment(max_steps=max_steps, seed=42)
    env.reset(seed=42)

    truncated = False
    for step_i in range(max_steps):
        # Pick break (A6) in S0 which keeps student in non-terminal states
        _, _, terminated, truncated, _ = env.step(6)
        if terminated:
            break

    if not terminated:
        assert truncated is True
        assert env.step_count == max_steps


def test_reproducible_seeding():
    """Verify two runs with the same seed yield identical transition trajectories."""
    env1 = LearnerEnvironment(seed=999)
    env2 = LearnerEnvironment(seed=999)

    s1, _ = env1.reset(seed=999)
    s2, _ = env2.reset(seed=999)
    assert s1 == s2

    actions = [0, 1, 2, 3, 4]
    traj1 = []
    traj2 = []

    for a in actions:
        next_s1, r1, term1, _, _ = env1.step(a)
        next_s2, r2, term2, _, _ = env2.step(a)
        traj1.append((next_s1, r1, term1))
        traj2.append((next_s2, r2, term2))

    assert traj1 == traj2
