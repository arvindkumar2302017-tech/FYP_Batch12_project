# Personalized Adaptive Learning and Sequential Path Recommendation Using Reinforcement Learning with Improved Q-Learning

[![Python 3.9+](https://img.shields.io/badge/Python-3.9%2B-blue.svg)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.28%2B-FF4B4B.svg)](https://streamlit.io/)
[![pytest](https://img.shields.io/badge/pytest-Passing-brightgreen.svg)](https://pytest.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**Final-Year Computer Science and Engineering (CSE) Capstone Project — Phase I Implementation**  
Strictly aligned with the Base Paper Formulation and Second Review Presentation Scope.

---

## 1. Project Abstract & Overview

Traditional e-learning platforms offer static, one-size-fits-all curricula that fail to adapt to individual student engagement and cognitive friction. Students subjected to premature challenges experience **frustration and cognitive overload**, while those subjected to repetitive passive reading become **bored and disengaged**, frequently resulting in course abandonment.

This project implements an intelligent, adaptive sequential path recommendation system formulated as a finite **Markov Decision Process (MDP)**. Using **Improved Q-Learning** (enhanced with epsilon exploration decay, Robbins-Monro learning rate decay, step-penalty reward shaping, and repeated-action fatigue penalties), the recommendation agent learns an optimal pedagogical policy $\pi^*(s)$ that maximizes student learning outcomes, minimizes dropouts, and avoids repetitive fatigue.

For fair empirical benchmarking, the system compares:
1. **Improved Q-Learning** (Off-policy TD control with four algorithmic enhancements)
2. **SARSA** (On-policy TD control baseline under identical reward shaping and discount)
3. **Random Policy Baseline** (Uniform stochastic exploration baseline)

All three policies are evaluated across **100, 200, and 500 episode budgets** over 100 seeded evaluation runs.

---

## 2. Mathematical Formulation & Algorithmic Core

### 2.1 Markov Decision Process (MDP)

The adaptive learning system is modeled as a 5-tuple $\langle \mathcal{S}, \mathcal{A}, \mathcal{P}, \mathcal{R}, \gamma \rangle$:
- $\mathcal{S}$: Exactly **11 Consistently Defined Learner States** ($S_0$ through $S_{10}$)
- $\mathcal{A}$: Exactly **8 Pedagogical Recommendation Actions** ($A_0$ through $A_7$)
- $\mathcal{P}(s' \mid s, a)$: Documented transition probability distribution $\sum_{s'} P(s' \mid s, a) = 1.0$
- $\mathcal{R}(s, a, s')$: Pedagogical reward matrix reflecting mastery milestones and disengagement penalties
- $\gamma$: Discount factor ($\gamma = 0.95$, configurable)

---

### 2.2 Exactly 11 Learner States

| State ID | Name | Category / Affect | Pedagogical Description | Base Reward |
| :---: | :--- | :--- | :--- | :---: |
| **S0** | `S0_START` | Initial Entry | Course registration and preliminary diagnostic assessment | 0.0 |
| **S1** | `S1_READING_CONCEPT` | Active Learning | Student studying theoretical textbooks and conceptual guides | +5.0 |
| **S2** | `S2_VIDEO_LECTURE` | Active Learning | Student watching multimedia video tutorials and animated lectures | +5.0 |
| **S3** | `S3_WRITING_EXERCISE` | Active Learning | Student actively coding, writing exercises, and lab tasks | +8.0 |
| **S4** | `S4_INTERMEDIATE_QUIZ` | Evaluation | Formative milestone assessment testing concept retention | +10.0 |
| **S5** | `S5_ADVANCED_TOPIC` | Mastery | Challenging deep-dive capstone projects and advanced theory | +15.0 |
| **S6** | `S6_REVISION_REVIEW` | Remediation | Remedial review notes targeting misconceptions from quizzes | +4.0 |
| **S7** | `S7_BORED` | Negative Affect | Under-stimulation from excessive passive repetition | -8.0 |
| **S8** | `S8_FRUSTRATED` | Negative Affect | Severe cognitive friction and overload from difficult jumps | -12.0 |
| **S9** | `S9_COMPLETED` | **Terminal Success** | Course mastery achieved and certified | **+100.0** |
| **S10** | `S10_DROPOUT` | **Terminal Failure** | Student abandoned the curriculum due to fatigue or frustration | **-60.0** |

---

### 2.3 Exactly 8 Pedagogical Actions

| Action ID | Action Label | Pedagogical Objective |
| :---: | :--- | :--- |
| **A0** | `A0_RECOMMEND_READING` | Assign theoretical reading materials and documentation. |
| **A1** | `A1_RECOMMEND_VIDEO` | Assign multimedia video tutorials and visual demonstrations. |
| **A2** | `A2_RECOMMEND_PRACTICE` | Assign hands-on coding, writing exercises, and interactive labs. |
| **A3** | `A3_RECOMMEND_QUIZ` | Trigger a formative checkpoint quiz to evaluate comprehension. |
| **A4** | `A4_RECOMMEND_ADVANCED` | Recommend higher-order advanced challenges and capstones. |
| **A5** | `A5_RECOMMEND_REVIEW` | Provide remedial review walkthroughs and error analysis. |
| **A6** | `A6_RECOMMEND_BREAK` | Recommend a structured rest interval to alleviate cognitive fatigue. |
| **A7** | `A7_RECOMMEND_EXAM` | Direct learner to the final summative certification examination. |

---

### 2.4 Improved Q-Learning Innovations

1. **Step-Penalty Reward Shaping**:
   To encourage efficient sequential paths and prevent cyclical wandering:
   $$R_{\text{step}}(s, a, s') = R_{\text{raw}}(s, a, s') + \lambda_{\text{step}}, \quad (\lambda_{\text{step}} = -1.0)$$

2. **Repeated-Action Penalty (Fatigue Mitigation)**:
   Penalizes consecutive recommendations of the identical action ($a_t = a_{t-1}$) to prevent monotonous passive fatigue:
   $$R_{\text{effective}} = R_{\text{step}} + \begin{cases} \rho_{\text{repeat}} & \text{if } a_t = a_{t-1} \\ 0 & \text{otherwise} \end{cases}, \quad (\rho_{\text{repeat}} = -2.5)$$

3. **Epsilon Exploration Decay**:
   Exploration starts at 100% and decays monotonically per episode down to 5%:
   $$\epsilon_{e+1} = \max\left(\epsilon_{\min}, \epsilon_e \times d_\epsilon\right), \quad \epsilon_0 = 1.0, \; \epsilon_{\min} = 0.05, \; d_\epsilon = 0.985$$

4. **Robbins-Monro Learning Rate Decay**:
   Prevents value oscillations and satisfies stochastic convergence conditions:
   $$\alpha(e) = \max\left(\alpha_{\min}, \frac{\alpha_0}{1 + \delta_\alpha \cdot e}\right), \quad \alpha_0 = 0.20, \; \delta_\alpha = 0.005, \; \alpha_{\min} = 0.02$$

5. **Bellman Optimality Update**:
   $$Q(s, a) \leftarrow Q(s, a) + \alpha(e) \left[ R_{\text{effective}} + \gamma \max_{a'} Q(s', a') \cdot (1 - \text{term}) - Q(s, a) \right]$$

---

### 2.5 SARSA Baseline (On-Policy TD Control)

$$Q(s, a) \leftarrow Q(s, a) + \alpha(e) \left[ R_{\text{effective}} + \gamma Q(s', a') \cdot (1 - \text{term}) - Q(s, a) \right]$$
where $a'$ is sampled via $\epsilon$-greedy action selection from the policy at state $s'$.

---

## 3. Measured Empirical Benchmark Results

Evaluation conducted over **100 independent seeded test rollouts** per trained model under pure greedy exploitation ($\epsilon = 0$):

| Algorithm | Episode Budget | Success Rate (%) | Mean Reward | Std Reward | Avg Path Length | Dropout Rate (%) | Truncation Rate (%) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Improved Q-Learning** | 100 | **100.0%** | +128.74 | 13.53 | 6.95 steps | 0.0% | 0.0% |
| **Improved Q-Learning** | 200 | **99.0%** | **+155.50** | 29.13 | 8.73 steps | 0.0% | 1.0% |
| **Improved Q-Learning** | 500 | **99.0%** | +142.19 | 16.41 | 7.09 steps | 0.0% | 1.0% |
| **SARSA** | 100 | **100.0%** | +132.05 | 14.76 | 6.88 steps | 0.0% | 0.0% |
| **SARSA** | 200 | **100.0%** | +132.29 | 10.33 | 6.23 steps | 0.0% | 0.0% |
| **SARSA** | 500 | **100.0%** | +133.32 | 12.48 | 6.44 steps | 0.0% | 0.0% |
| **Random Policy** | 100 | 12.0% | -28.26 | 75.60 | 7.88 steps | 86.0% | 2.0% |
| **Random Policy** | 200 | 10.0% | -34.79 | 69.62 | 7.69 steps | 86.0% | 4.0% |
| **Random Policy** | 500 | 14.0% | -25.27 | 71.88 | 7.52 steps | 84.0% | 2.0% |

> **Key Findings**:
> - Both Improved Q-Learning and SARSA achieve **99–100% completion rates** and positive mean returns (+128 to +155), discovering efficient pedagogical paths of ~6–7 steps from diagnostic entry to certification.
> - The Random baseline suffers an **84–86% dropout rate**, verifying the necessity of reinforcement learning for personalized sequential adaptation.

---

## 4. Project Directory Structure

```
Batch_12/
├── app.py                      # Interactive Streamlit Web Application
├── environment.py              # 11 States, 8 Actions, Transition Dynamics, Rewards
├── agents.py                   # Improved Q-Learning, SARSA, and Random Baseline
├── training.py                 # Training loops, early stopping, episode logging
├── evaluation.py               # Evaluation protocol, metric computation, trajectory simulation
├── utils.py                    # Seaborn/Matplotlib visualization routines & serialization
├── run_experiments.py          # Automated batch experiment benchmark script
├── requirements.txt            # Dependency specifications
├── README.md                   # Complete documentation and setup manual
├── models/                     # Saved JSON Q-tables and model artifacts
│   ├── q_learning_100ep.json
│   ├── q_learning_200ep.json
│   ├── q_learning_500ep.json
│   ├── sarsa_100ep.json
│   ├── sarsa_200ep.json
│   ├── sarsa_500ep.json
│   ├── random_100ep.json
│   ├── random_200ep.json
│   └── random_500ep.json
├── results/                    # Benchmark metrics and training history exports
│   ├── benchmark_summary.csv
│   ├── benchmark_summary.json
│   └── training_histories.json
└── tests/                      # Comprehensive pytest test suite (22 unit tests)
    ├── __init__.py
    ├── test_environment.py
    ├── test_agents.py
    ├── test_training.py
    └── test_evaluation.py
```

---

## 5. Setup & Execution Guide (Windows PowerShell)

Follow these exact commands in Windows PowerShell:

### Step 1: Open PowerShell in Project Directory
```powershell
cd c:\Users\SRIT\Downloads\Batch_12
```

### Step 2: (Optional) Create and Activate Virtual Environment
```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### Step 3: Install Dependencies
```powershell
py -3 -m pip install -r requirements.txt
```

### Step 4: Run Unit Tests (22 Tests)
```powershell
py -3 -m pytest tests -v
```
*Expected Output: `22 passed in 0.60s`.*

### Step 5: (Optional) Re-run Multi-Budget Experiments
```powershell
py -3 run_experiments.py
```

### Step 6: Launch Streamlit Web Application
```powershell
py -3 -m streamlit run app.py
```
Open your browser to: **`http://localhost:8501`**.

---

## 6. Streamlit Dashboard Features Walkthrough

The web dashboard provides 6 comprehensive views:
1. **Project Overview & Scope**: Full MDP formalization, 11 states table, 8 actions table, and mathematical equations.
2. **Sequential Path Recommender**: Select any student state to view the optimal recommended activity, expected Q-value breakdown, or simulate a full end-to-end learning path.
3. **Interactive Q-Table Heatmap**: $11 \times 8$ Seaborn heatmap with state labels and action names, state values $V^*(s)$ bar chart, and extracted optimal policy $\pi^*(s)$.
4. **Model Training & Convergence Lab**: Interactive sliders for learning rate decay, epsilon decay, step penalties, and early stopping; train models in real time and observe live learning curves.
5. **Comparative Benchmarks (100/200/500)**: Side-by-side comparison of Improved Q-Learning, SARSA, and Random Policy across all budgets with actual measured metrics.
6. **Model Persistence & Export Center**: Inspect, download, and export trained Q-tables and benchmark summaries as CSV and JSON.

---

## 7. Scope & Compliance Notes

- **Phase I Tabular Implementation**: Strictly lightweight tabular RL using NumPy, Pandas, Matplotlib, Seaborn, and Streamlit.
- **Laptop Friendly**: Executes smoothly on any standard laptop without GPUs, databases, paid APIs, or deep learning overhead.
- **Academic Rigor**: All transition probabilities sum to 1.0; all benchmark metrics are empirically measured with reproducible random seeds.
