"""
app.py
======
Personalized Adaptive Learning and Sequential Path Recommendation Using
Reinforcement Learning with Improved Q-Learning.

Interactive Streamlit Web Dashboard for Final-Year CSE Project (Phase I).
Features:
- Theoretical overview and base paper formulation.
- Interactive next-activity recommendation and sequential path generator.
- Interactive Q-table heatmap and optimal policy viewer.
- Live training lab with hyperparameters, convergence diagnostics, and early stopping.
- Multi-budget empirical benchmark comparison (100, 200, 500 episodes).
- Model persistence, save/load feedback, and data export.
"""

import os
import json
import time
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from environment import (
    LearnerEnvironment,
    NUM_STATES,
    NUM_ACTIONS,
    STATE_START,
    STATE_COMPLETED,
    STATE_DROPOUT,
    STATE_NAMES,
    ACTION_NAMES,
    STATE_DESCRIPTIONS,
    ACTION_DESCRIPTIONS,
    BASE_REWARD_TABLE,
)
from agents import (
    BaseRLAgent,
    ImprovedQLearningAgent,
    SARSAgent,
    RandomPolicyAgent,
)
from training import train_agent
from evaluation import evaluate_policy, simulate_single_path, run_benchmark_suite
from utils import (
    plot_reward_curves,
    plot_cumulative_rewards,
    plot_q_table_heatmap,
    plot_state_values,
    plot_benchmark_comparison,
)

# ==============================================================================
# STREAMLIT CONFIGURATION & STYLING
# ==============================================================================
st.set_page_config(
    page_title="Adaptive Learning RL Dashboard",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for rich aesthetics and clean typography
st.markdown(
    """
    <style>
    /* Global Styles */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    .main-title {
        font-size: 2.1rem;
        font-weight: 800;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        font-size: 1.05rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 16px;
        text-align: center;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .metric-val {
        font-size: 1.8rem;
        font-weight: 700;
        color: #1E3A8A;
    }
    .metric-label {
        font-size: 0.85rem;
        color: #64748B;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .path-step-card {
        background: #FFFFFF;
        border-left: 4px solid #3B82F6;
        padding: 10px 14px;
        margin-bottom: 8px;
        border-radius: 6px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04);
    }
    .badge-success {
        background-color: #DEF7EC;
        color: #03543F;
        padding: 3px 8px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.8rem;
    }
    .badge-danger {
        background-color: #FDE8E8;
        color: #9B1C1C;
        padding: 3px 8px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.8rem;
    }
    .badge-info {
        background-color: #E1EFFE;
        color: #1E429F;
        padding: 3px 8px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.8rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# ==============================================================================
# HELPER FUNCTIONS TO LOAD PERSISTED ARTIFACTS
# ==============================================================================
@st.cache_data
def load_benchmark_summary():
    csv_path = os.path.join("results", "benchmark_summary.csv")
    if os.path.exists(csv_path):
        return pd.read_csv(csv_path)
    return None


@st.cache_data
def load_training_histories():
    hist_path = os.path.join("results", "training_histories.json")
    if os.path.exists(hist_path):
        with open(hist_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def get_available_models():
    models_dir = "models"
    if not os.path.exists(models_dir):
        return []
    return [f for f in os.listdir(models_dir) if f.endswith(".json")]


def load_agent_from_file(filename: str) -> BaseRLAgent:
    path = os.path.join("models", filename)
    with open(path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    
    name = meta.get("name", "Agent")
    if "sarsa" in filename.lower():
        agent = SARSAgent(name=name)
    elif "random" in filename.lower():
        agent = RandomPolicyAgent(name=name)
    else:
        agent = ImprovedQLearningAgent(name=name)

    agent.load(path)
    return agent


# Initialize session state for active trained model if needed
if "current_agent" not in st.session_state:
    models = get_available_models()
    if "q_learning_500ep.json" in models:
        st.session_state["current_agent"] = load_agent_from_file("q_learning_500ep.json")
        st.session_state["current_model_file"] = "q_learning_500ep.json"
    elif models:
        st.session_state["current_agent"] = load_agent_from_file(models[0])
        st.session_state["current_model_file"] = models[0]
    else:
        q_init = ImprovedQLearningAgent(seed=42)
        st.session_state["current_agent"] = q_init
        st.session_state["current_model_file"] = "in-memory-untrained"


# ==============================================================================
# SIDEBAR NAVIGATION & CONTROLS
# ==============================================================================
st.sidebar.image("https://img.icons8.com/color/96/artificial-intelligence.png", width=64)
st.sidebar.title("Navigation")
menu_option = st.sidebar.radio(
    "Select Project View:",
    [
        "1. Project Overview & Scope",
        "2. Sequential Path Recommender",
        "3. Interactive Q-Table Heatmap",
        "4. Model Training & Convergence Lab",
        "5. Comparative Benchmarks (100/200/500)",
        "6. Model Persistence & Export",
    ],
)

st.sidebar.markdown("---")
st.sidebar.subheader("Active Model")
avail_models = get_available_models()

if avail_models:
    sel_model = st.sidebar.selectbox(
        "Loaded Q-Table Model:",
        avail_models,
        index=avail_models.index(st.session_state["current_model_file"])
        if st.session_state["current_model_file"] in avail_models else 0,
    )
    if sel_model != st.session_state["current_model_file"]:
        st.session_state["current_agent"] = load_agent_from_file(sel_model)
        st.session_state["current_model_file"] = sel_model
        st.sidebar.success(f"Switched to {sel_model}")
else:
    st.sidebar.info("No saved model files found in `models/`.")

st.sidebar.caption(
    "Final Year CSE Project | Tabular RL Phase I\n"
    "Personalized Sequential Learning Path"
)


# ==============================================================================
# VIEW 1: PROJECT OVERVIEW & SCOPE
# ==============================================================================
if menu_option == "1. Project Overview & Scope":
    st.markdown('<div class="main-title">Personalized Adaptive Learning and Sequential Path Recommendation</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Reinforcement Learning with Improved Q-Learning | Final-Year CSE Project (Phase I)</div>', unsafe_allow_html=True)

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(
            '<div class="metric-card"><div class="metric-val">11</div><div class="metric-label">Learner States</div></div>',
            unsafe_allow_html=True,
        )
    with col2:
        st.markdown(
            '<div class="metric-card"><div class="metric-val">8</div><div class="metric-label">Pedagogical Actions</div></div>',
            unsafe_allow_html=True,
        )
    with col3:
        st.markdown(
            '<div class="metric-card"><div class="metric-val">3</div><div class="metric-label">Algorithms Compared</div></div>',
            unsafe_allow_html=True,
        )
    with col4:
        st.markdown(
            '<div class="metric-card"><div class="metric-val">100 / 200 / 500</div><div class="metric-label">Episode Budgets</div></div>',
            unsafe_allow_html=True,
        )

    st.markdown("---")
    st.subheader("1. Problem Statement & Motivation")
    st.markdown(
        r"""
        Conventional computer-aided educational systems deliver rigid, one-size-fits-all curricula.
        Students experience cognitive overload when faced with prematurely challenging content, or disengage 
        due to excessive monotonous passive reading. 

        This project formulates **Personalized Sequential Path Recommendation** as a finite **Markov Decision Process (MDP)**:
        - The learner is an interactive environment with cognitive and emotional states (including **Reading**, **Video**, **Writing/Practice**, **Boredom**, **Frustration**, **Completion**, and **Dropout**).
        - An **Improved Q-Learning Agent** learns an optimal sequential recommendation policy $\pi^*(s)$ that maximizes cumulative pedagogical return, guides learners toward **Course Completion**, minimizes dropouts, and avoids repetitive fatigue.
        """
    )

    tab1, tab2, tab3 = st.tabs(["Curricular States (11)", "Recommendation Actions (8)", "Mathematical Formulations"])

    with tab1:
        st.markdown("### Consistently Defined 11 Learner States")
        state_rows = []
        for s in range(NUM_STATES):
            nature = (
                "Terminal Success" if s == STATE_COMPLETED else (
                    "Terminal Failure" if s == STATE_DROPOUT else (
                        "Negative Affect" if s in [7, 8] else "Active Learning"
                    )
                )
            )
            state_rows.append({
                "State ID": f"S{s}",
                "Name": STATE_NAMES[s],
                "Category / Affect": nature,
                "Pedagogical Meaning": STATE_DESCRIPTIONS[s],
                "Base Reward": BASE_REWARD_TABLE.get(s, 0.0),
            })
        st.dataframe(pd.DataFrame(state_rows), use_container_width=True, hide_index=True)

    with tab2:
        st.markdown("### Exactly 8 Pedagogical Recommendation Actions")
        action_rows = []
        for a in range(NUM_ACTIONS):
            action_rows.append({
                "Action ID": f"A{a}",
                "Action Label": ACTION_NAMES[a],
                "Pedagogical Objective": ACTION_DESCRIPTIONS[a],
            })
        st.dataframe(pd.DataFrame(action_rows), use_container_width=True, hide_index=True)

    with tab3:
        st.markdown("### Algorithmic Foundations & Mathematical Equations")
        st.markdown(
            r"""
            #### 1. Bellman Optimality Equation (Q-Learning)
            $$Q^*(s, a) = \mathbb{E} \left[ R(s, a, s') + \gamma \max_{a'} Q^*(s', a') \;\middle|\; s, a \right]$$

            #### 2. Improved Q-Learning Enhancements
            1. **Step-Penalty Reward Shaping**: Encourages the shortest, most efficient learning trajectory:
               $$R_{\text{shaped}}(s, a, s') = R_{\text{raw}}(s, a, s') + \lambda_{\text{step}}$$
            2. **Repeated-Action Penalty**: Discourages consecutive identical recommendations to prevent fatigue:
               $$R_{\text{effective}} = R_{\text{shaped}} + \begin{cases} \rho_{\text{repeat}} & \text{if } a_t = a_{t-1} \\ 0 & \text{otherwise} \end{cases}$$
            3. **Epsilon Exploration Decay**:
               $$\epsilon_{t+1} = \max\left(\epsilon_{\min}, \epsilon_t \times d_\epsilon\right), \quad \epsilon_0 = 1.0 \to \epsilon_{\min} = 0.05$$
            4. **Learning Rate Decay (Robbins-Monro Condition)**:
               $$\alpha(e) = \max\left(\alpha_{\min}, \frac{\alpha_0}{1 + \delta_\alpha \cdot e}\right)$$
            5. **Q-Table Update Rule**:
               $$Q(s, a) \leftarrow Q(s, a) + \alpha(e) \left[ R_{\text{effective}} + \gamma \max_{a'} Q(s', a') (1 - \text{term}) - Q(s, a) \right]$$

            #### 3. SARSA On-Policy TD Control Baseline
            $$Q(s, a) \leftarrow Q(s, a) + \alpha \left[ R_{\text{effective}} + \gamma Q(s', a') (1 - \text{term}) - Q(s, a) \right]$$
            *(Where $a'$ is chosen by the current $\epsilon$-greedy policy in state $s'$)*

            #### 4. Random Policy Baseline
            Selects uniform random actions $a \sim \text{Uniform}(0, 7)$ without value iteration.
            """
        )


# ==============================================================================
# VIEW 2: SEQUENTIAL PATH RECOMMENDER & LIVE SIMULATOR
# ==============================================================================
elif menu_option == "2. Sequential Path Recommender":
    st.markdown('<div class="main-title">🧭 Sequential Path Recommender & Simulator</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Query the trained agent for optimal next activities or simulate complete learning paths</div>', unsafe_allow_html=True)

    agent = st.session_state["current_agent"]
    st.info(f"Using Active Policy: **{agent.name}** (`{st.session_state['current_model_file']}`)")

    col_sim_left, col_sim_right = st.columns([1, 1])

    with col_sim_left:
        st.subheader("1. Single-State Recommendation Query")
        selected_state = st.selectbox(
            "Select Current Student State:",
            options=list(range(NUM_STATES)),
            format_func=lambda s: STATE_NAMES[s],
            index=0,
        )

        st.caption(f"**State Description:** {STATE_DESCRIPTIONS[selected_state]}")
        
        # Compute best action
        q_vals = agent.q_table[selected_state]
        best_act = int(np.argmax(q_vals))
        
        st.markdown(
            f"""
            <div style="background-color: #EFF6FF; border: 2px solid #3B82F6; border-radius: 8px; padding: 16px; margin: 12px 0;">
                <span style="font-size: 0.85rem; color: #1E40AF; font-weight: 600;">RECOMMENDED NEXT ACTIVITY</span>
                <h3 style="margin: 4px 0; color: #1E3A8A;">{ACTION_NAMES[best_act]}</h3>
                <p style="margin: 4px 0 0 0; color: #374151; font-size: 0.95rem;">{ACTION_DESCRIPTIONS[best_act]}</p>
                <div style="margin-top: 8px; font-size: 0.9rem; color: #1D4ED8; font-weight: bold;">
                    Expected Q-Value: {q_vals[best_act]:.2f}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        # Plot horizontal bar chart of all 8 action Q-values for selected state
        fig, ax = plt.subplots(figsize=(7, 3.8), dpi=100)
        action_labels = [ACTION_NAMES[a] for a in range(NUM_ACTIONS)]
        colors = ["#2563EB" if a == best_act else "#94A3B8" for a in range(NUM_ACTIONS)]
        
        bars = ax.barh(action_labels, q_vals, color=colors, height=0.6)
        ax.axvline(0, color="black", linewidth=0.8, linestyle="--")
        ax.set_title(f"Action Q-Values in State {STATE_NAMES[selected_state].split(':')[0]}", fontsize=11, fontweight="bold")
        ax.set_xlabel("Estimated Return Q(s, a)", fontsize=9)
        plt.tight_layout()
        st.pyplot(fig)

    with col_sim_right:
        st.subheader("2. Complete Sequential Path Generation")
        st.write("Simulate the end-to-end learning path followed by a student under the greedy policy.")
        
        start_state_sim = st.selectbox(
            "Path Starting State:",
            options=list(range(NUM_STATES)),
            format_func=lambda s: STATE_NAMES[s],
            index=0,
            key="start_sim",
        )
        sim_seed = st.number_input("Simulation Seed (for reproducible environment transitions):", value=42, step=1)
        
        if st.button("Generate Full Learned Path", type="primary"):
            env = LearnerEnvironment()
            sim_df = simulate_single_path(
                env=env,
                agent=agent,
                initial_state=start_state_sim,
                max_steps=25,
                seed=int(sim_seed),
            )
            
            if not sim_df.empty:
                last_step = sim_df.iloc[-1]
                completed = "Success" in str(last_step["Terminal"])
                total_reward = sim_df["Step Reward"].sum()
                num_steps = len(sim_df)

                # Metrics banner
                c1, c2, c3 = st.columns(3)
                c1.metric("Path Length", f"{num_steps} steps")
                c2.metric("Cumulative Reward", f"{total_reward:.1f}")
                c3.metric("Terminal Outcome", "COMPLETED 🎉" if completed else "DROPOUT ⚠️")

                st.markdown("#### Sequential Progression Trajectory")
                st.dataframe(sim_df, use_container_width=True, hide_index=True)
            else:
                st.warning("Selected state is already terminal.")


# ==============================================================================
# VIEW 3: INTERACTIVE Q-TABLE HEATMAP & POLICY VISUALIZER
# ==============================================================================
elif menu_option == "3. Interactive Q-Table Heatmap":
    st.markdown('<div class="main-title">🧠 Interactive Q-Table Heatmap & Policy Visualizer</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Inspect learned action-value Q(s, a) matrix, state values V*(s), and optimal decision policy</div>', unsafe_allow_html=True)

    agent = st.session_state["current_agent"]
    st.info(f"Visualizing Q-Table for: **{agent.name}** (`{st.session_state['current_model_file']}`)")

    tab_hm, tab_v, tab_pol = st.tabs(["11×8 Q-Table Heatmap", "State Values V*(s)", "Extracted Optimal Policy π*(s)"])

    with tab_hm:
        fig_hm = plot_q_table_heatmap(
            agent.q_table,
            title=f"Action-Value Matrix Q(s, a) - {agent.name}",
        )
        st.pyplot(fig_hm)

        st.markdown("#### Raw Q-Table Values")
        df_q = pd.DataFrame(
            agent.q_table,
            index=[STATE_NAMES[i] for i in range(NUM_STATES)],
            columns=[ACTION_NAMES[j] for j in range(NUM_ACTIONS)],
        )
        st.dataframe(df_q.style.format("{:.2f}").background_gradient(cmap="coolwarm", axis=None), use_container_width=True)

    with tab_v:
        fig_v = plot_state_values(
            agent.q_table,
            title=f"State Values V*(s) = max_a Q(s, a) - {agent.name}",
        )
        st.pyplot(fig_v)

        st.markdown(
            """
            > **Pedagogical Insight**: States close to certification (e.g. *S5 Advanced Mastery*, *S4 Quiz*) 
            exhibit positive state values, whereas disengaged states (*S7 Boredom*, *S8 Frustration*, *S10 Dropout*) 
            demonstrate depressed state values reflecting their high risk of abandonment.
            """
        )

    with tab_pol:
        st.subheader(r"Optimal Recommendation Policy Map: $\pi^*(s) = \arg\max_a Q(s, a)$")
        pol_rows = []
        best_actions = agent.get_policy()
        for s in range(NUM_STATES):
            act = best_actions[s]
            max_val = agent.q_table[s, act]
            pol_rows.append({
                "State": STATE_NAMES[s],
                "Optimal Recommendation": ACTION_NAMES[act],
                "Action Details": ACTION_DESCRIPTIONS[act],
                "Expected Value": round(max_val, 2),
            })
        st.dataframe(pd.DataFrame(pol_rows), use_container_width=True, hide_index=True)


# ==============================================================================
# VIEW 4: MODEL TRAINING & CONVERGENCE LAB
# ==============================================================================
elif menu_option == "4. Model Training & Convergence Lab":
    st.markdown('<div class="main-title">🚀 Model Training & Convergence Lab</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Train agents with custom hyperparameters, observe real-time learning curves, and test early stopping</div>', unsafe_allow_html=True)

    col_ctrl, col_chart = st.columns([1, 2])

    with col_ctrl:
        st.subheader("Training Hyperparameters")
        algo_choice = st.selectbox(
            "Algorithm:",
            ["Improved Q-Learning", "SARSA", "Random Policy Baseline"],
            index=0,
        )

        ep_budget = st.selectbox(
            "Episode Budget:",
            options=[100, 200, 500, 1000],
            index=1,
        )

        st.markdown("##### Learning Rate & Discount")
        gamma_param = st.slider("Discount Factor (gamma):", min_value=0.50, max_value=0.99, value=0.95, step=0.01)
        lr_init_param = st.slider("Initial Learning Rate (alpha_0):", min_value=0.05, max_value=0.50, value=0.20, step=0.01)
        lr_decay_param = st.slider("Learning Rate Decay Rate:", min_value=0.001, max_value=0.050, value=0.005, step=0.001, format="%.3f")

        st.markdown("##### Epsilon Exploration")
        eps_init_param = 1.0
        eps_min_param = 0.05
        eps_decay_param = st.slider("Epsilon Decay Factor:", min_value=0.90, max_value=0.999, value=0.985, step=0.001, format="%.3f")
        st.caption("Epsilon decays from 1.0 down to min 0.05.")

        st.markdown("##### Reward Shaping Penalties")
        step_penalty_param = st.slider("Step Penalty (per transition):", min_value=-5.0, max_value=0.0, value=-1.0, step=0.5)
        repeat_penalty_param = st.slider("Repeated Action Penalty:", min_value=-5.0, max_value=0.0, value=-2.5, step=0.5)

        st.markdown("##### Early Stopping Criterion")
        enable_early_stop = st.checkbox("Enable Early Stopping", value=False)
        conv_tol = st.slider("Convergence Tolerance (Delta Q):", min_value=0.001, max_value=0.05, value=0.005, step=0.001, format="%.3f")
        patience_val = st.slider("Patience (Episodes):", min_value=10, max_value=50, value=20, step=5)

        train_seed = st.number_input("Random Seed:", value=42, step=1)
        
        train_btn = st.button("🚀 Train Agent Now", type="primary")

    with col_chart:
        if train_btn:
            st.subheader("Training Execution & Diagnostics")
            progress_bar = st.progress(0.0)
            status_text = st.empty()

            env = LearnerEnvironment(seed=int(train_seed))

            # Instantiate agent
            if algo_choice == "Improved Q-Learning":
                trained_agent = ImprovedQLearningAgent(
                    gamma=gamma_param,
                    lr_init=lr_init_param,
                    lr_min=0.02,
                    lr_decay=lr_decay_param,
                    epsilon_init=eps_init_param,
                    epsilon_min=eps_min_param,
                    epsilon_decay=eps_decay_param,
                    step_penalty=step_penalty_param,
                    repetition_penalty=repeat_penalty_param,
                    seed=int(train_seed),
                )
            elif algo_choice == "SARSA":
                trained_agent = SARSAgent(
                    gamma=gamma_param,
                    lr_init=lr_init_param,
                    lr_min=0.02,
                    lr_decay=lr_decay_param,
                    epsilon_init=eps_init_param,
                    epsilon_min=eps_min_param,
                    epsilon_decay=eps_decay_param,
                    step_penalty=step_penalty_param,
                    repetition_penalty=repeat_penalty_param,
                    seed=int(train_seed),
                )
            else:
                trained_agent = RandomPolicyAgent(seed=int(train_seed))

            def update_progress(curr, total, meta):
                progress_bar.progress(curr / total)
                status_text.text(f"Episode {curr}/{total} | Last Reward: {meta['reward']:.1f} | Length: {meta['length']} | Outcome: {meta['outcome']}")

            # Run training
            res = train_agent(
                env=env,
                agent=trained_agent,
                num_episodes=int(ep_budget),
                early_stopping=enable_early_stop,
                convergence_tol=conv_tol,
                patience=patience_val,
                seed=int(train_seed),
                progress_callback=update_progress,
            )

            progress_bar.progress(1.0)
            status_text.success(
                f"Training Complete in {res['training_time_seconds']}s! "
                + (f"Early stopped at episode {res['converged_episode']}." if res['converged'] else f"Completed full {ep_budget} episodes.")
            )

            # Store in session state
            st.session_state["current_agent"] = trained_agent
            st.session_state["current_model_file"] = f"custom_trained_{int(time.time())}.json"
            
            # Save automatically
            save_path = os.path.join("models", st.session_state["current_model_file"])
            trained_agent.save(save_path, extra_meta={"episodes": ep_budget, "res": res["converged"]})

            # Plot training curves
            st.markdown("#### Reward Learning Curve")
            fig_r = plot_reward_curves({trained_agent.name: res}, window=10)
            st.pyplot(fig_r)

            st.markdown("#### Cumulative Reward Accumulation")
            fig_c = plot_cumulative_rewards({trained_agent.name: res})
            st.pyplot(fig_c)

            # Convergence metrics
            col_m1, col_m2, col_m3 = st.columns(3)
            col_m1.metric("Episodes Completed", f"{res['episodes_completed']} / {ep_budget}")
            col_m2.metric("Converged Status", "YES (Early Stopped)" if res["converged"] else "FULL BUDGET")
            col_m3.metric("Final Exploration (Epsilon)", f"{getattr(trained_agent, 'current_epsilon', 0.0):.3f}")

        else:
            st.info("Adjust hyperparameters in the left panel and click **'🚀 Train Agent Now'** to initiate training.")
            
            # Show existing training histories if available
            hist_data = load_training_histories()
            if hist_data:
                st.subheader("Pre-Computed Training Progression (500 Episodes)")
                sub_hist = {}
                for k in ["q_learning_500", "sarsa_500", "random_500"]:
                    if k in hist_data:
                        label = (
                            "Improved Q-Learning" if "q_learning" in k else (
                                "SARSA" if "sarsa" in k else "Random Policy"
                            )
                        )
                        sub_hist[label] = hist_data[k]

                if sub_hist:
                    fig_pre = plot_reward_curves(sub_hist, window=15, title="Comparative Training Curves (500 Episodes)")
                    st.pyplot(fig_pre)


# ==============================================================================
# VIEW 5: COMPARATIVE BENCHMARKS (100 / 200 / 500 EPISODES)
# ==============================================================================
elif menu_option == "5. Comparative Benchmarks (100/200/500)":
    st.markdown('<div class="main-title">📊 Empirical Benchmark & Comparative Analytics</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Actual measured results comparing Improved Q-Learning vs SARSA vs Random Policy at 100, 200, and 500 episodes</div>', unsafe_allow_html=True)

    df_bench = load_benchmark_summary()

    if df_bench is not None:
        st.subheader("1. Summary Benchmark Table (Actual Measured Values)")
        st.dataframe(
            df_bench.style.highlight_max(subset=["Success Rate (%)", "Mean Reward"], color="#D1FAE5")
            .highlight_min(subset=["Avg Path Length", "Dropout Rate (%)"], color="#FEF3C7"),
            use_container_width=True,
            hide_index=True,
        )

        st.markdown("---")
        st.subheader("2. Comparative Performance Visualizations")
        fig_comp = plot_benchmark_comparison(df_bench)
        st.pyplot(fig_comp)

        st.markdown("---")
        st.subheader("3. Comprehensive Quantitative Analysis")
        col_an1, col_an2, col_an3 = st.columns(3)

        q_rows = df_bench[df_bench["Algorithm"] == "Improved Q-Learning"]
        s_rows = df_bench[df_bench["Algorithm"] == "SARSA"]
        r_rows = df_bench[df_bench["Algorithm"] == "Random Policy"]

        with col_an1:
            st.markdown(
                f"""
                <div class="metric-card">
                    <div class="metric-val">{q_rows['Success Rate (%)'].mean():.1f}%</div>
                    <div class="metric-label">Improved Q-Learning Success Rate</div>
                    <p style="margin-top: 8px; font-size: 0.85rem; color: #475569;">
                        Average Mean Reward: <b>{q_rows['Mean Reward'].mean():.1f}</b><br>
                        Average Path Length: <b>{q_rows['Avg Path Length'].mean():.1f} steps</b>
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )

        with col_an2:
            st.markdown(
                f"""
                <div class="metric-card">
                    <div class="metric-val">{s_rows['Success Rate (%)'].mean():.1f}%</div>
                    <div class="metric-label">SARSA Baseline Success Rate</div>
                    <p style="margin-top: 8px; font-size: 0.85rem; color: #475569;">
                        Average Mean Reward: <b>{s_rows['Mean Reward'].mean():.1f}</b><br>
                        Average Path Length: <b>{s_rows['Avg Path Length'].mean():.1f} steps</b>
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )

        with col_an3:
            st.markdown(
                f"""
                <div class="metric-card">
                    <div class="metric-val">{r_rows['Success Rate (%)'].mean():.1f}%</div>
                    <div class="metric-label">Random Baseline Success Rate</div>
                    <p style="margin-top: 8px; font-size: 0.85rem; color: #475569;">
                        Average Mean Reward: <b>{r_rows['Mean Reward'].mean():.1f}</b><br>
                        Average Dropout Rate: <b>{r_rows['Dropout Rate (%)'].mean():.1f}%</b>
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )

        st.markdown("---")
        st.subheader("4. Re-run Multi-Seed Benchmark Suite")
        st.write("Optionally trigger a live re-evaluation of all algorithms across 100, 200, 500 episodes with custom seeds:")
        
        bench_eval_runs = st.slider("Evaluation Episodes per Algorithm-Budget Pair:", min_value=20, max_value=200, value=50, step=10)
        re_run_seed = st.number_input("Benchmark Seed:", value=999, step=1)

        if st.button("Run Fresh Benchmark Suite", type="primary"):
            with st.spinner("Executing multi-budget experiments..."):
                from run_experiments import run_all
                new_df = run_all(
                    budgets=[100, 200, 500],
                    base_seed=int(re_run_seed),
                    num_eval_episodes=int(bench_eval_runs),
                )
                st.success("Benchmark completed and saved to `results/`!")
                st.dataframe(new_df, use_container_width=True, hide_index=True)
                st.cache_data.clear()
    else:
        st.warning("No benchmark summary found in `results/benchmark_summary.csv`. Run `py -3 run_experiments.py` first.")


# ==============================================================================
# VIEW 6: MODEL PERSISTENCE & EXPORT CENTER
# ==============================================================================
elif menu_option == "6. Model Persistence & Export":
    st.markdown('<div class="main-title">💾 Model Persistence & Export Center</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Inspect saved Q-table artifacts, download CSV/JSON reports, and view experiment logs</div>', unsafe_allow_html=True)

    models_dir = "models"
    results_dir = "results"
    
    col_dl1, col_dl2 = st.columns(2)

    with col_dl1:
        st.subheader("Saved Q-Table Models")
        models = get_available_models()
        if models:
            for m in models:
                m_path = os.path.join(models_dir, m)
                size_kb = os.path.getsize(m_path) / 1024
                st.write(f"📄 **`{m}`** ({size_kb:.1f} KB)")
                with open(m_path, "r", encoding="utf-8") as f:
                    content = f.read()
                st.download_button(
                    label=f"Download {m}",
                    data=content,
                    file_name=m,
                    mime="application/json",
                    key=f"dl_{m}",
                )
        else:
            st.info("No models found in `models/`.")

    with col_dl2:
        st.subheader("Benchmark & Results Export")
        bench_csv = os.path.join(results_dir, "benchmark_summary.csv")
        if os.path.exists(bench_csv):
            with open(bench_csv, "r", encoding="utf-8") as f:
                csv_data = f.read()
            st.download_button(
                label="📥 Download Benchmark Summary (CSV)",
                data=csv_data,
                file_name="benchmark_summary.csv",
                mime="text/csv",
                type="primary",
            )

        bench_json = os.path.join(results_dir, "benchmark_summary.json")
        if os.path.exists(bench_json):
            with open(bench_json, "r", encoding="utf-8") as f:
                json_data = f.read()
            st.download_button(
                label="📥 Download Full Benchmark Data (JSON)",
                data=json_data,
                file_name="benchmark_summary.json",
                mime="application/json",
            )

    st.markdown("---")
    st.subheader("Active Model Inspection (JSON Dump)")
    st.json({
        "agent_name": st.session_state["current_agent"].name,
        "active_file": st.session_state["current_model_file"],
        "num_states": st.session_state["current_agent"].num_states,
        "num_actions": st.session_state["current_agent"].num_actions,
        "optimal_policy": st.session_state["current_agent"].get_policy().tolist(),
        "sample_q_values_state_0": st.session_state["current_agent"].q_table[0].tolist(),
    })
