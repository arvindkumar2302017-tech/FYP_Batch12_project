"""
environment.py
==============
Personalized Adaptive Learning and Sequential Path Recommendation Environment.

Models a learner simulation environment with exactly 11 consistently defined states
and 8 recommendation actions. Complies strictly with the CSE final-year project
specifications, tabular RL dynamics, reproducible seeding, documented transition
probabilities, and pedagogical reward tables.
"""

from typing import Dict, List, Optional, Tuple, Any
import numpy as np


# ==============================================================================
# 1. STATE DEFINITIONS (EXACTLY 11 STATES)
# ==============================================================================
STATE_START = 0          # S0: Course Entry & Knowledge Diagnostic Assessment
STATE_READING = 1        # S1: Reading Conceptual Text & Theoretical Guides
STATE_VIDEO = 2          # S2: Watching Video Lecture / Multimedia Demonstration
STATE_WRITING = 3        # S3: Writing Code & Interactive Practice Exercises
STATE_QUIZ = 4           # S4: Intermediate Formative Evaluation / Milestone Quiz
STATE_ADVANCED = 5       # S5: Advanced Topic Mastery & Capstone Challenge
STATE_REVISION = 6       # S6: Remedial Revision & Concept Reinforcement
STATE_BORED = 7          # S7: Boredom / Disengaged Emotional State
STATE_FRUSTRATED = 8     # S8: Frustration / Cognitive Overload State
STATE_COMPLETED = 9      # S9: Course Completion & Certified (Terminal Success)
STATE_DROPOUT = 10       # S10: Course Dropout / Abandoned (Terminal Failure)

NUM_STATES = 11

STATE_NAMES: Dict[int, str] = {
    STATE_START: "S0: Start / Diagnostic",
    STATE_READING: "S1: Reading Theory",
    STATE_VIDEO: "S2: Video Lecture",
    STATE_WRITING: "S3: Writing / Practice",
    STATE_QUIZ: "S4: Intermediate Quiz",
    STATE_ADVANCED: "S5: Advanced Mastery",
    STATE_REVISION: "S6: Remedial Review",
    STATE_BORED: "S7: Bored / Disengaged",
    STATE_FRUSTRATED: "S8: Frustrated / Overloaded",
    STATE_COMPLETED: "S9: Completed (Goal)",
    STATE_DROPOUT: "S10: Dropout (Quit)",
}

STATE_DESCRIPTIONS: Dict[int, str] = {
    STATE_START: "Initial student registration and preliminary diagnostic assessment.",
    STATE_READING: "Student actively studying theoretical textbook chapters and documentation.",
    STATE_VIDEO: "Student viewing multimedia tutorials, animated demos, or recorded lectures.",
    STATE_WRITING: "Student engaged in active coding, written exercises, and problem solving.",
    STATE_QUIZ: "Formative checkpoint testing retention and conceptual mastery.",
    STATE_ADVANCED: "Deep-dive challenging projects, advanced algorithms, and mastery tasks.",
    STATE_REVISION: "Targeted revision addressing specific weaknesses revealed by assessments.",
    STATE_BORED: "Low cognitive stimulation due to excessive repetition or lack of active challenge.",
    STATE_FRUSTRATED: "Excessive cognitive friction, difficult jumps, or consecutive failures.",
    STATE_COMPLETED: "Learner successfully completed curricular milestones and earned certification.",
    STATE_DROPOUT: "Learner disengaged, exhausted, or abandoned the curriculum prematurely.",
}

TERMINAL_STATES = {STATE_COMPLETED, STATE_DROPOUT}


# ==============================================================================
# 2. ACTION DEFINITIONS (EXACTLY 8 ACTIONS)
# ==============================================================================
ACTION_READING = 0       # A0: Recommend Theory / Reading Guide
ACTION_VIDEO = 1         # A1: Recommend Video Tutorial / Multimedia Lecture
ACTION_PRACTICE = 2      # A2: Recommend Interactive Coding / Writing Task
ACTION_QUIZ = 3          # A3: Recommend Intermediate Quiz / Checkpoint
ACTION_ADVANCED = 4      # A4: Recommend Advanced Topic / Challenge Problem
ACTION_REVIEW = 5        # A5: Recommend Remedial Revision / Concept Reinforcement
ACTION_BREAK = 6         # A6: Recommend Rest Break / Cognitive Reset
ACTION_EXAM = 7          # A7: Recommend Final Certification Assessment

NUM_ACTIONS = 8

ACTION_NAMES: Dict[int, str] = {
    ACTION_READING: "A0: Recommend Reading",
    ACTION_VIDEO: "A1: Recommend Video",
    ACTION_PRACTICE: "A2: Recommend Practice",
    ACTION_QUIZ: "A3: Recommend Quiz",
    ACTION_ADVANCED: "A4: Recommend Advanced",
    ACTION_REVIEW: "A5: Recommend Review",
    ACTION_BREAK: "A6: Recommend Break",
    ACTION_EXAM: "A7: Recommend Exam",
}

ACTION_DESCRIPTIONS: Dict[int, str] = {
    ACTION_READING: "Assign structured theoretical reading materials and documentation.",
    ACTION_VIDEO: "Assign explanatory multimedia video tutorials and visual demonstrations.",
    ACTION_PRACTICE: "Assign practical hands-on coding, writing exercises, and lab tasks.",
    ACTION_QUIZ: "Trigger a formative assessment to benchmark learner understanding.",
    ACTION_ADVANCED: "Recommend higher-order advanced challenges and capstone activities.",
    ACTION_REVIEW: "Provide remedial review notes, walkthroughs, and error analysis.",
    ACTION_BREAK: "Encourage a structured rest break to alleviate cognitive fatigue.",
    ACTION_EXAM: "Direct learner to the final summative certification examination.",
}


# ==============================================================================
# 3. TRANSITION DYNAMICS P(s' | s, a)
# ==============================================================================
# Dictionary mapping: state -> action -> dict of {next_state: probability}
# Guarantees sum(probs.values()) == 1.0 for every (state, action) pair.
TRANSITION_PROBABILITIES: Dict[int, Dict[int, Dict[int, float]]] = {
    STATE_START: {
        ACTION_READING:  {STATE_READING: 0.75, STATE_VIDEO: 0.15, STATE_BORED: 0.10},
        ACTION_VIDEO:    {STATE_VIDEO: 0.80, STATE_READING: 0.15, STATE_BORED: 0.05},
        ACTION_PRACTICE: {STATE_WRITING: 0.50, STATE_READING: 0.20, STATE_FRUSTRATED: 0.30},
        ACTION_QUIZ:     {STATE_QUIZ: 0.40, STATE_FRUSTRATED: 0.50, STATE_REVISION: 0.10},
        ACTION_ADVANCED: {STATE_FRUSTRATED: 0.70, STATE_DROPOUT: 0.20, STATE_ADVANCED: 0.10},
        ACTION_REVIEW:   {STATE_READING: 0.60, STATE_BORED: 0.40},
        ACTION_BREAK:    {STATE_START: 0.70, STATE_BORED: 0.30},
        ACTION_EXAM:     {STATE_FRUSTRATED: 0.60, STATE_DROPOUT: 0.35, STATE_COMPLETED: 0.05},
    },
    STATE_READING: {
        ACTION_READING:  {STATE_BORED: 0.60, STATE_READING: 0.30, STATE_WRITING: 0.10},
        ACTION_VIDEO:    {STATE_VIDEO: 0.75, STATE_READING: 0.20, STATE_WRITING: 0.05},
        ACTION_PRACTICE: {STATE_WRITING: 0.80, STATE_QUIZ: 0.15, STATE_FRUSTRATED: 0.05},
        ACTION_QUIZ:     {STATE_QUIZ: 0.65, STATE_REVISION: 0.25, STATE_FRUSTRATED: 0.10},
        ACTION_ADVANCED: {STATE_FRUSTRATED: 0.55, STATE_ADVANCED: 0.30, STATE_REVISION: 0.15},
        ACTION_REVIEW:   {STATE_REVISION: 0.60, STATE_BORED: 0.30, STATE_READING: 0.10},
        ACTION_BREAK:    {STATE_READING: 0.75, STATE_VIDEO: 0.20, STATE_BORED: 0.05},
        ACTION_EXAM:     {STATE_FRUSTRATED: 0.65, STATE_DROPOUT: 0.25, STATE_REVISION: 0.10},
    },
    STATE_VIDEO: {
        ACTION_READING:  {STATE_READING: 0.70, STATE_WRITING: 0.20, STATE_BORED: 0.10},
        ACTION_VIDEO:    {STATE_BORED: 0.60, STATE_VIDEO: 0.30, STATE_READING: 0.10},
        ACTION_PRACTICE: {STATE_WRITING: 0.85, STATE_QUIZ: 0.10, STATE_READING: 0.05},
        ACTION_QUIZ:     {STATE_QUIZ: 0.70, STATE_REVISION: 0.20, STATE_FRUSTRATED: 0.10},
        ACTION_ADVANCED: {STATE_FRUSTRATED: 0.50, STATE_ADVANCED: 0.35, STATE_REVISION: 0.15},
        ACTION_REVIEW:   {STATE_REVISION: 0.65, STATE_BORED: 0.25, STATE_VIDEO: 0.10},
        ACTION_BREAK:    {STATE_VIDEO: 0.70, STATE_READING: 0.25, STATE_BORED: 0.05},
        ACTION_EXAM:     {STATE_FRUSTRATED: 0.65, STATE_DROPOUT: 0.25, STATE_REVISION: 0.10},
    },
    STATE_WRITING: {
        ACTION_READING:  {STATE_READING: 0.60, STATE_WRITING: 0.30, STATE_BORED: 0.10},
        ACTION_VIDEO:    {STATE_VIDEO: 0.65, STATE_WRITING: 0.30, STATE_FRUSTRATED: 0.05},
        ACTION_PRACTICE: {STATE_WRITING: 0.60, STATE_QUIZ: 0.25, STATE_FRUSTRATED: 0.15},
        ACTION_QUIZ:     {STATE_QUIZ: 0.85, STATE_ADVANCED: 0.10, STATE_REVISION: 0.05},
        ACTION_ADVANCED: {STATE_ADVANCED: 0.60, STATE_FRUSTRATED: 0.30, STATE_QUIZ: 0.10},
        ACTION_REVIEW:   {STATE_REVISION: 0.70, STATE_WRITING: 0.20, STATE_READING: 0.10},
        ACTION_BREAK:    {STATE_WRITING: 0.75, STATE_QUIZ: 0.20, STATE_BORED: 0.05},
        ACTION_EXAM:     {STATE_FRUSTRATED: 0.50, STATE_COMPLETED: 0.25, STATE_REVISION: 0.25},
    },
    STATE_QUIZ: {
        ACTION_READING:  {STATE_READING: 0.60, STATE_REVISION: 0.30, STATE_BORED: 0.10},
        ACTION_VIDEO:    {STATE_VIDEO: 0.65, STATE_REVISION: 0.25, STATE_BORED: 0.10},
        ACTION_PRACTICE: {STATE_WRITING: 0.70, STATE_ADVANCED: 0.20, STATE_QUIZ: 0.10},
        ACTION_QUIZ:     {STATE_BORED: 0.50, STATE_QUIZ: 0.35, STATE_FRUSTRATED: 0.15},
        ACTION_ADVANCED: {STATE_ADVANCED: 0.80, STATE_FRUSTRATED: 0.15, STATE_REVISION: 0.05},
        ACTION_REVIEW:   {STATE_REVISION: 0.80, STATE_WRITING: 0.15, STATE_READING: 0.05},
        ACTION_BREAK:    {STATE_QUIZ: 0.65, STATE_ADVANCED: 0.25, STATE_BORED: 0.10},
        ACTION_EXAM:     {STATE_COMPLETED: 0.40, STATE_FRUSTRATED: 0.45, STATE_DROPOUT: 0.15},
    },
    STATE_ADVANCED: {
        ACTION_READING:  {STATE_ADVANCED: 0.50, STATE_READING: 0.30, STATE_BORED: 0.20},
        ACTION_VIDEO:    {STATE_ADVANCED: 0.55, STATE_VIDEO: 0.35, STATE_BORED: 0.10},
        ACTION_PRACTICE: {STATE_ADVANCED: 0.70, STATE_WRITING: 0.20, STATE_FRUSTRATED: 0.10},
        ACTION_QUIZ:     {STATE_QUIZ: 0.55, STATE_ADVANCED: 0.40, STATE_FRUSTRATED: 0.05},
        ACTION_ADVANCED: {STATE_ADVANCED: 0.55, STATE_FRUSTRATED: 0.30, STATE_BORED: 0.15},
        ACTION_REVIEW:   {STATE_REVISION: 0.70, STATE_ADVANCED: 0.25, STATE_READING: 0.05},
        ACTION_BREAK:    {STATE_ADVANCED: 0.80, STATE_BORED: 0.20},
        ACTION_EXAM:     {STATE_COMPLETED: 0.88, STATE_FRUSTRATED: 0.08, STATE_REVISION: 0.04},
    },
    STATE_REVISION: {
        ACTION_READING:  {STATE_READING: 0.75, STATE_WRITING: 0.20, STATE_BORED: 0.05},
        ACTION_VIDEO:    {STATE_VIDEO: 0.75, STATE_READING: 0.20, STATE_BORED: 0.05},
        ACTION_PRACTICE: {STATE_WRITING: 0.75, STATE_QUIZ: 0.20, STATE_FRUSTRATED: 0.05},
        ACTION_QUIZ:     {STATE_QUIZ: 0.70, STATE_FRUSTRATED: 0.20, STATE_REVISION: 0.10},
        ACTION_ADVANCED: {STATE_FRUSTRATED: 0.65, STATE_DROPOUT: 0.25, STATE_ADVANCED: 0.10},
        ACTION_REVIEW:   {STATE_BORED: 0.55, STATE_REVISION: 0.35, STATE_READING: 0.10},
        ACTION_BREAK:    {STATE_REVISION: 0.65, STATE_READING: 0.25, STATE_BORED: 0.10},
        ACTION_EXAM:     {STATE_FRUSTRATED: 0.70, STATE_DROPOUT: 0.25, STATE_COMPLETED: 0.05},
    },
    STATE_BORED: {
        ACTION_READING:  {STATE_DROPOUT: 0.60, STATE_BORED: 0.30, STATE_READING: 0.10},
        ACTION_VIDEO:    {STATE_VIDEO: 0.70, STATE_WRITING: 0.20, STATE_BORED: 0.10},
        ACTION_PRACTICE: {STATE_WRITING: 0.75, STATE_READING: 0.15, STATE_BORED: 0.10},
        ACTION_QUIZ:     {STATE_QUIZ: 0.65, STATE_WRITING: 0.20, STATE_BORED: 0.15},
        ACTION_ADVANCED: {STATE_ADVANCED: 0.45, STATE_FRUSTRATED: 0.35, STATE_DROPOUT: 0.20},
        ACTION_REVIEW:   {STATE_BORED: 0.55, STATE_DROPOUT: 0.35, STATE_REVISION: 0.10},
        ACTION_BREAK:    {STATE_READING: 0.60, STATE_VIDEO: 0.30, STATE_BORED: 0.10},
        ACTION_EXAM:     {STATE_FRUSTRATED: 0.55, STATE_DROPOUT: 0.40, STATE_COMPLETED: 0.05},
    },
    STATE_FRUSTRATED: {
        ACTION_READING:  {STATE_FRUSTRATED: 0.55, STATE_DROPOUT: 0.35, STATE_READING: 0.10},
        ACTION_VIDEO:    {STATE_VIDEO: 0.65, STATE_REVISION: 0.25, STATE_FRUSTRATED: 0.10},
        ACTION_PRACTICE: {STATE_DROPOUT: 0.50, STATE_FRUSTRATED: 0.35, STATE_WRITING: 0.15},
        ACTION_QUIZ:     {STATE_FRUSTRATED: 0.60, STATE_DROPOUT: 0.35, STATE_QUIZ: 0.05},
        ACTION_ADVANCED: {STATE_DROPOUT: 0.75, STATE_FRUSTRATED: 0.25},
        ACTION_REVIEW:   {STATE_REVISION: 0.75, STATE_READING: 0.20, STATE_FRUSTRATED: 0.05},
        ACTION_BREAK:    {STATE_READING: 0.65, STATE_VIDEO: 0.25, STATE_FRUSTRATED: 0.10},
        ACTION_EXAM:     {STATE_DROPOUT: 0.85, STATE_FRUSTRATED: 0.15},
    },
    STATE_COMPLETED: {
        a: {STATE_COMPLETED: 1.0} for a in range(NUM_ACTIONS)
    },
    STATE_DROPOUT: {
        a: {STATE_DROPOUT: 1.0} for a in range(NUM_ACTIONS)
    },
}


# ==============================================================================
# 4. ENVIRONMENT BASE REWARDS TABLE
# ==============================================================================
# Pedagogical reward received upon transitioning into next_state:
BASE_REWARD_TABLE: Dict[int, float] = {
    STATE_COMPLETED: 100.0,    # Major milestone: successfully certified
    STATE_DROPOUT: -60.0,      # Major penalty: student abandoned course
    STATE_FRUSTRATED: -12.0,   # Negative affect: severe cognitive fatigue / overload
    STATE_BORED: -8.0,         # Negative affect: loss of interest / under-stimulation
    STATE_ADVANCED: 15.0,      # High positive progress: advanced mastery level
    STATE_QUIZ: 10.0,          # Positive checkpoint: tested retention
    STATE_WRITING: 8.0,        # Active constructive engagement: writing / coding
    STATE_VIDEO: 5.0,          # Multimedia intake: foundational absorption
    STATE_READING: 5.0,        # Textual study: foundational absorption
    STATE_REVISION: 4.0,       # Remedial recovery: fixing cognitive gaps
    STATE_START: 0.0,          # Neutral starting state
}


# ==============================================================================
# 5. LEARNER SIMULATION ENVIRONMENT CLASS
# ==============================================================================
class LearnerEnvironment:
    """
    Simulation Environment for Adaptive Sequential Learning Path Recommendation.
    
    Adheres strictly to the Gym/Gymnasium tabular API design:
    - reset(seed=None) -> (state, info)
    - step(action) -> (next_state, reward, terminated, truncated, info)
    
    Attributes:
        num_states (int): 11
        num_actions (int): 8
        state (int): Current learner state in [0, 10]
        max_steps (int): Step budget per episode to guard against infinite cycles
        step_count (int): Current episode step index
        prev_action (Optional[int]): Last action executed (for repetition detection)
        rng (np.random.Generator): Reproducible random number generator
    """

    def __init__(self, max_steps: int = 30, seed: Optional[int] = None):
        self.num_states = NUM_STATES
        self.num_actions = NUM_ACTIONS
        self.max_steps = max_steps
        self.rng = np.random.default_rng(seed)
        
        self.state: int = STATE_START
        self.step_count: int = 0
        self.prev_action: Optional[int] = None
        self.trajectory: List[Tuple[int, int, float, int]] = []

    def reset(self, seed: Optional[int] = None) -> Tuple[int, Dict[str, Any]]:
        """
        Resets the simulation to the initial diagnostic entry state S0.
        
        Args:
            seed (Optional[int]): Random seed for deterministic reproducibility.
            
        Returns:
            Tuple[int, Dict[str, Any]]: (initial_state, metadata_dict)
        """
        if seed is not None:
            self.rng = np.random.default_rng(seed)
            
        self.state = STATE_START
        self.step_count = 0
        self.prev_action = None
        self.trajectory = []
        
        info = {
            "state_name": STATE_NAMES[self.state],
            "step_count": self.step_count,
            "is_terminal": False,
        }
        return self.state, info

    def step(self, action: int) -> Tuple[int, float, bool, bool, Dict[str, Any]]:
        """
        Executes one pedagogical recommendation action.
        
        Args:
            action (int): Recommended pedagogical action in [0, 7].
            
        Returns:
            Tuple[int, float, bool, bool, Dict[str, Any]]:
                next_state, reward, terminated, truncated, info
        """
        if not (0 <= action < self.num_actions):
            raise ValueError(f"Invalid action {action}. Must be in range [0, {self.num_actions - 1}].")

        # If already in terminal state, stay there with 0 reward
        if self.state in TERMINAL_STATES:
            return self.state, 0.0, True, False, {
                "state_name": STATE_NAMES[self.state],
                "action_name": ACTION_NAMES[action],
                "prev_state": self.state,
                "step_count": self.step_count,
                "is_terminal": True,
                "reason": "Already terminal",
            }

        curr_state = self.state
        self.step_count += 1

        # Retrieve transition probabilities for (curr_state, action)
        transition_dict = TRANSITION_PROBABILITIES[curr_state][action]
        possible_next_states = list(transition_dict.keys())
        probabilities = list(transition_dict.values())

        # Sample next state based on documented transition distribution
        next_state = int(self.rng.choice(possible_next_states, p=probabilities))
        
        # Base environmental reward
        reward = float(BASE_REWARD_TABLE.get(next_state, 0.0))
        
        # Check termination and truncation
        terminated = next_state in TERMINAL_STATES
        truncated = (self.step_count >= self.max_steps) and not terminated

        # Record step trajectory
        self.trajectory.append((curr_state, action, reward, next_state))
        
        # Update internal state
        self.prev_action = action
        self.state = next_state

        info = {
            "prev_state": curr_state,
            "prev_state_name": STATE_NAMES[curr_state],
            "action": action,
            "action_name": ACTION_NAMES[action],
            "next_state": next_state,
            "next_state_name": STATE_NAMES[next_state],
            "step_count": self.step_count,
            "is_terminal": terminated,
            "is_truncated": truncated,
            "base_reward": reward,
        }
        return next_state, reward, terminated, truncated, info

    def get_transition_matrix(self) -> np.ndarray:
        """
        Builds a full 3D numpy transition matrix P[s, a, s'].
        Shape: (NUM_STATES, NUM_ACTIONS, NUM_STATES).
        """
        P = np.zeros((NUM_STATES, NUM_ACTIONS, NUM_STATES), dtype=np.float64)
        for s in range(NUM_STATES):
            for a in range(NUM_ACTIONS):
                trans = TRANSITION_PROBABILITIES[s][a]
                for next_s, prob in trans.items():
                    P[s, a, next_s] = prob
        return P

    def get_reward_matrix(self) -> np.ndarray:
        """
        Builds a full 3D numpy reward matrix R[s, a, s'].
        Shape: (NUM_STATES, NUM_ACTIONS, NUM_STATES).
        """
        R = np.zeros((NUM_STATES, NUM_ACTIONS, NUM_STATES), dtype=np.float64)
        for s in range(NUM_STATES):
            for a in range(NUM_ACTIONS):
                for next_s in range(NUM_STATES):
                    if s in TERMINAL_STATES:
                        R[s, a, next_s] = 0.0
                    else:
                        R[s, a, next_s] = BASE_REWARD_TABLE.get(next_s, 0.0)
        return R

    def describe_state(self, state: int) -> Dict[str, str]:
        """Returns human-readable state meta."""
        return {
            "name": STATE_NAMES.get(state, f"S{state}"),
            "description": STATE_DESCRIPTIONS.get(state, "Unknown state"),
        }

    def describe_action(self, action: int) -> Dict[str, str]:
        """Returns human-readable action meta."""
        return {
            "name": ACTION_NAMES.get(action, f"A{action}"),
            "description": ACTION_DESCRIPTIONS.get(action, "Unknown action"),
        }
