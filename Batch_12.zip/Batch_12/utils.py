"""
utils.py
========
Visualization, Plotting, and Serialization Utilities.

Generates Matplotlib/Seaborn figures for:
- Reward-per-episode learning curves (raw + moving average).
- Cumulative reward trajectories.
- Interactive and publication-ready Q-Table heatmaps.
- Multi-budget benchmark comparison charts (Success rate, Mean reward, Path length).
- State-Value V(s) bar charts.
"""

from typing import Dict, List, Optional, Tuple, Any
import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from environment import (
    NUM_STATES,
    NUM_ACTIONS,
    STATE_NAMES,
    ACTION_NAMES,
)


# Set consistent aesthetics
sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.size"] = 10


def plot_reward_curves(
    histories: Dict[str, Dict[str, Any]],
    window: int = 10,
    title: str = "Training Reward Progression per Episode",
) -> plt.Figure:
    """
    Plots training reward progression across algorithms with moving averages.
    """
    fig, ax = plt.subplots(figsize=(10, 5), dpi=120)
    
    colors = {
        "Improved Q-Learning": "#1f77b4",
        "SARSA": "#ff7f0e",
        "Random Policy": "#7f7f7f",
    }

    for algo_name, res in histories.items():
        rewards = res["history"]["episode_rewards"]
        episodes = np.arange(1, len(rewards) + 1)
        color = colors.get(algo_name, None)

        # Plot raw rewards lightly
        ax.plot(episodes, rewards, alpha=0.22, color=color, linewidth=1.0)
        
        # Plot moving average
        if len(rewards) >= window:
            rolling_mean = pd.Series(rewards).rolling(window=window, min_periods=1).mean()
            ax.plot(
                episodes,
                rolling_mean,
                label=f"{algo_name} (MA {window})",
                color=color,
                linewidth=2.2,
            )
        else:
            ax.plot(episodes, rewards, label=algo_name, color=color, linewidth=2.0)

    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Episode", fontsize=11, fontweight="semibold")
    ax.set_ylabel("Episode Reward", fontsize=11, fontweight="semibold")
    ax.legend(loc="lower right", frameon=True, framealpha=0.9)
    plt.tight_layout()
    return fig


def plot_cumulative_rewards(
    histories: Dict[str, Dict[str, Any]],
    title: str = "Cumulative Training Reward Accumulation",
) -> plt.Figure:
    """
    Plots cumulative reward curve over episodes for compared algorithms.
    """
    fig, ax = plt.subplots(figsize=(10, 5), dpi=120)
    colors = {
        "Improved Q-Learning": "#1f77b4",
        "SARSA": "#ff7f0e",
        "Random Policy": "#7f7f7f",
    }

    for algo_name, res in histories.items():
        cum_rewards = res.get("cumulative_rewards", [])
        if not cum_rewards:
            rewards = res["history"]["episode_rewards"]
            cum_rewards = np.cumsum(rewards).tolist()

        episodes = np.arange(1, len(cum_rewards) + 1)
        ax.plot(
            episodes,
            cum_rewards,
            label=algo_name,
            color=colors.get(algo_name, None),
            linewidth=2.5,
        )

    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Episode", fontsize=11, fontweight="semibold")
    ax.set_ylabel("Cumulative Reward", fontsize=11, fontweight="semibold")
    ax.legend(loc="upper left", frameon=True, framealpha=0.9)
    plt.tight_layout()
    return fig


def plot_q_table_heatmap(
    q_table: np.ndarray,
    title: str = "Learned Action-Value Q(s, a) Heatmap",
) -> plt.Figure:
    """
    Renders an 11x8 heatmap of learned Q-values with state and action labels.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=120)
    
    y_labels = [STATE_NAMES[i] for i in range(NUM_STATES)]
    x_labels = [ACTION_NAMES[j] for j in range(NUM_ACTIONS)]

    # Draw heatmap with diverging colormap
    sns.heatmap(
        q_table,
        annot=True,
        fmt=".1f",
        cmap="coolwarm",
        center=0.0,
        xticklabels=x_labels,
        yticklabels=y_labels,
        cbar_kws={"label": "Expected Return Q(s, a)"},
        linewidths=0.5,
        ax=ax,
    )

    ax.set_title(title, fontsize=14, fontweight="bold", pad=14)
    ax.set_xlabel("Recommendation Actions", fontsize=11, fontweight="semibold")
    ax.set_ylabel("Learner States", fontsize=11, fontweight="semibold")
    plt.xticks(rotation=30, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()
    return fig


def plot_state_values(
    q_table: np.ndarray,
    title: str = "Estimated State Values V*(s) = max_a Q(s, a)",
) -> plt.Figure:
    """
    Plots the maximum state values V(s) = max_a Q(s, a) across all 11 states.
    """
    fig, ax = plt.subplots(figsize=(10, 4.5), dpi=120)
    v_values = np.max(q_table, axis=1)
    state_labels = [STATE_NAMES[i].split(":")[0] + " " + STATE_NAMES[i].split(":")[1][:8] for i in range(NUM_STATES)]

    colors = ["#2ca02c" if v > 0 else "#d62728" for v in v_values]
    bars = ax.bar(state_labels, v_values, color=colors, width=0.6, edgecolor="black", linewidth=0.6)

    for bar, val in zip(bars, v_values):
        y_pos = val + (2 if val >= 0 else -6)
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            y_pos,
            f"{val:.1f}",
            ha="center",
            va="bottom" if val >= 0 else "top",
            fontsize=8.5,
            fontweight="bold",
        )

    ax.axhline(0, color="gray", linewidth=0.8, linestyle="--")
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax.set_ylabel("State Value V*(s)", fontsize=11, fontweight="semibold")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    return fig


def plot_benchmark_comparison(df: pd.DataFrame) -> plt.Figure:
    """
    Plots a multi-panel comparison across Algorithms and Episode Budgets (100, 200, 500):
    1. Success Rate (%)
    2. Mean Episode Reward
    3. Average Path Length
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.8), dpi=120)

    # 1. Success Rate
    sns.barplot(
        data=df,
        x="Budget",
        y="Success Rate (%)",
        hue="Algorithm",
        ax=axes[0],
        palette="Blues_d",
    )
    axes[0].set_title("Success Rate (%)", fontweight="bold")
    axes[0].set_ylabel("Success Rate (%)")
    axes[0].set_ylim(0, 105)

    # 2. Mean Reward
    sns.barplot(
        data=df,
        x="Budget",
        y="Mean Reward",
        hue="Algorithm",
        ax=axes[1],
        palette="Oranges_d",
    )
    axes[1].set_title("Mean Episode Reward", fontweight="bold")
    axes[1].set_ylabel("Reward")

    # 3. Path Length
    sns.barplot(
        data=df,
        x="Budget",
        y="Avg Path Length",
        hue="Algorithm",
        ax=axes[2],
        palette="Greens_d",
    )
    axes[2].set_title("Avg Path Length (Steps)", fontweight="bold")
    axes[2].set_ylabel("Steps to Termination")

    for ax in axes:
        ax.set_xlabel("Episode Budget", fontweight="semibold")
        if ax.get_legend():
            ax.get_legend().remove()

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1.05), ncol=3, frameon=True)
    plt.tight_layout()
    return fig
